import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'l10n.dart';

// =====================================================================
//  Apple Human Interface Guidelines uslubidagi umumiy dizayn vidjetlari.
//  (Fayl va klass nomlari oldingi versiya bilan bir xil — faqat koʻrinish.)
// =====================================================================

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

Color sysBlue(BuildContext c) => isDark(c) ? kBlueDark : kBlue;
Color sysBg(BuildContext c) => isDark(c) ? Colors.black : const Color(0xFFF2F2F7);
Color sysCard(BuildContext c) => isDark(c) ? const Color(0xFF1C1C1E) : Colors.white;
Color sysSep(BuildContext c) => isDark(c) ? const Color(0xFF38383A) : const Color(0xFFC6C6C8);
Color sysLabel2(BuildContext c) => isDark(c) ? const Color(0x99EBEBF5) : const Color(0x993C3C43);
Color sysFill(BuildContext c) => isDark(c) ? const Color(0x5C787880) : const Color(0x1F787880);
Color sysBar(BuildContext c) => isDark(c) ? const Color(0xE61C1C1E) : const Color(0xE6F9F9F9);

/// Butun ilova foni: systemGroupedBackground.
class Aurora extends StatelessWidget {
  final Widget child;
  const Aurora({super.key, required this.child});

  @override
  Widget build(BuildContext context) => ColoredBox(color: sysBg(context), child: child);
}

/// Panel: oddiy holatda toʻq qoplama (card), `blur > 0` boʻlsa yarim shaffof "material".
class Glass extends StatelessWidget {
  final Widget child;
  final double radius, blur;
  final EdgeInsetsGeometry? padding, margin;
  final Gradient? tint;
  const Glass({super.key, required this.child, this.radius = 14, this.blur = 18, this.padding, this.margin, this.tint});

  @override
  Widget build(BuildContext context) {
    final br = BorderRadius.circular(radius);
    final translucent = blur > 0;
    Widget panel = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: br,
        gradient: tint,
        color: tint != null ? null : (translucent ? sysBar(context) : sysCard(context)),
      ),
      child: child,
    );
    if (translucent) {
      panel = BackdropFilter(filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30), child: panel);
    }
    return Container(margin: margin, child: ClipRRect(borderRadius: br, child: panel));
  }
}

/// Navigatsiya paneli fon qatlami (yarim shaffof + ingichka ajratgich): AppBar(flexibleSpace: glassBar())
Widget glassBar() => const _GlassBar();

class _GlassBar extends StatelessWidget {
  const _GlassBar();
  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          decoration: BoxDecoration(
            color: sysBar(context),
            border: Border(bottom: BorderSide(color: sysSep(context), width: 0.5)),
          ),
        ),
      ),
    );
  }
}

class NavItem {
  final IconData icon, activeIcon;
  final String label;
  const NavItem(this.icon, this.activeIcon, this.label);
}

/// Bosilganda yengil kichrayadigan (scale 0.97) umumiy qoplama.
class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  const Pressable({super.key, required this.child, this.onTap, this.scale = 0.97});
  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool down = false;
  void _set(bool v) {
    if (widget.onTap != null && down != v) setState(() => down = v);
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => _set(true),
        onTapUp: (_) => _set(false),
        onTapCancel: () => _set(false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: down ? widget.scale : 1,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      );
}

/// Liquid Glass: suzib turuvchi "pill" Tab bar (blur 20, yarim shaffof oq fon, ingichka chegara).
/// Faol boʻlim koʻk, orqasida yumshoq kulrang "pill".
class BubbleNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  final List<NavItem> items;
  const BubbleNav({super.key, required this.index, required this.onTap, required this.items});

  @override
  Widget build(BuildContext context) {
    final blue = sysBlue(context);
    final d = isDark(context);
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(34),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              height: 68,
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(34),
                color: d ? const Color(0x991C1C1E) : const Color(0xB3FFFFFF),
                border: Border.all(color: d ? const Color(0x24FFFFFF) : const Color(0x99FFFFFF), width: 0.8),
              ),
              child: Row(children: [
                for (var k = 0; k < items.length; k++)
                  Expanded(
                    child: Pressable(
                      onTap: () {
                        if (k != index) HapticFeedback.selectionClick();
                        onTap(k);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOut,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(28),
                          color: k == index ? (d ? const Color(0x33787880) : const Color(0x1A3C3C43)) : Colors.transparent,
                        ),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(k == index ? items[k].activeIcon : items[k].icon, size: 24, color: k == index ? blue : kGray),
                          const SizedBox(height: 2),
                          Text(items[k].label,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: k == index ? blue : kGray)),
                        ]),
                      ),
                    ),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------
//  Asosiy tugma (pill), Header, Qidiruv, Banner, Kartochka, Statistika
// ---------------------------------------------------------------------

class PillButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final bool loading, expand;
  final Color? color;
  const PillButton(this.text, {super.key, this.onTap, this.loading = false, this.expand = true, this.color});

  @override
  Widget build(BuildContext context) => Pressable(
        onTap: loading ? null : onTap,
        child: Container(
          height: 50,
          width: expand ? double.infinity : null,
          padding: const EdgeInsets.symmetric(horizontal: 28),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: (onTap == null && !loading) ? kGray : (color ?? sysBlue(context)), borderRadius: BorderRadius.circular(100)),
          child: loading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white))
              : Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: -0.4, color: Colors.white)),
        ),
      );
}

/// Header: chapda kichik avatar + "Xush kelibsiz" + ism, oʻngda asosiy amal tugmasi.
class AppHeader extends StatefulWidget {
  final IconData actionIcon;
  final VoidCallback onAction;
  const AppHeader({super.key, required this.actionIcon, required this.onAction});
  @override
  State<AppHeader> createState() => _AppHeaderState();
}

class _AppHeaderState extends State<AppHeader> {
  late final Future<Map<String, dynamic>> f = sb.from('profiles').select('name,username,avatar_url').eq('id', me).single();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FutureBuilder<Map<String, dynamic>>(
          future: f,
          builder: (_, s) {
            final p = s.data;
            final name = (p?['name'] ?? p?['username'] ?? '') as String;
            return Row(children: [
              avatar(p?['avatar_url'], name, r: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(t('welcome'), style: TextStyle(fontSize: 13, color: sysLabel2(context))),
                  Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: -0.4)),
                ]),
              ),
              Pressable(
                onTap: widget.onAction,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(color: sysBlue(context), shape: BoxShape.circle),
                  child: Icon(widget.actionIcon, size: 21, color: Colors.white),
                ),
              ),
            ]);
          },
        ),
      ),
    );
  }
}

class SearchField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  final String hint;
  const SearchField({super.key, required this.onChanged, required this.hint});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Container(
          height: 40,
          decoration: BoxDecoration(color: sysCard(context), borderRadius: BorderRadius.circular(12)),
          child: TextField(
            onChanged: onChanged,
            style: const TextStyle(fontSize: 17, letterSpacing: -0.4),
            decoration: InputDecoration(
              hintText: hint, filled: false, isDense: true,
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
          ),
        ),
      );
}

/// Banner: yumshoq gradient fonli katta kartochka (ikonka, sarlavha, izoh, ">").
class PromoBanner extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  const PromoBanner({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      child: Pressable(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: d ? const [Color(0xFF16305A), Color(0xFF2B1F4F)] : const [Color(0xFFDCEBFF), Color(0xFFEADFFF)],
            ),
          ),
          child: Row(children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(color: sysBlue(context), borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: -0.4)),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(fontSize: 14, color: sysLabel2(context))),
              ]),
            ),
            Icon(Icons.chevron_right_rounded, color: sysLabel2(context)),
          ]),
        ),
      ),
    );
  }
}

/// Kartochka: oq, yumaloq, ikonka + sarlavha + kulrang izoh (2 ustunli gridda ishlatiladi).
class TileCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, subtitle;
  final VoidCallback onTap;
  const TileCard({super.key, required this.icon, required this.color, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Pressable(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: sysCard(context), borderRadius: BorderRadius.circular(18)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: -0.4)),
              const SizedBox(height: 2),
              Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, color: sysLabel2(context))),
            ]),
          ]),
        ),
      );
}

/// Statistika: 3 ustunli oq blok, ustunlar orasida ajratuvchi chiziq.
class StatsBlock extends StatelessWidget {
  final List<(String, String)> items; // (raqam, yozuv)
  const StatsBlock({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    final cells = <Widget>[];
    for (var k = 0; k < items.length; k++) {
      if (k > 0) cells.add(VerticalDivider(width: 0.5, thickness: 0.5, color: sysSep(context)));
      cells.add(Expanded(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(items[k].$1, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
          const SizedBox(height: 2),
          Text(items[k].$2, style: TextStyle(fontSize: 13, color: sysLabel2(context))),
        ]),
      ));
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(color: sysCard(context), borderRadius: BorderRadius.circular(18)),
        child: IntrinsicHeight(child: Row(children: cells)),
      ),
    );
  }
}

// ---------------------------------------------------------------------
//  Katta sarlavha (Large Title)
// ---------------------------------------------------------------------

class LargeTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const LargeTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(
            child: Text(text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700, letterSpacing: 0.37, height: 1.15)),
          ),
          if (trailing != null) trailing!,
        ]),
      );
}

// ---------------------------------------------------------------------
//  Inset Grouped List: Group (yumaloq blok) + Cell (qator)
// ---------------------------------------------------------------------

class Group extends StatelessWidget {
  final List<Widget> children;
  final String? header;
  final double indent;
  final EdgeInsetsGeometry margin;
  const Group({super.key, required this.children, this.header, this.indent = 16, this.margin = const EdgeInsets.fromLTRB(16, 0, 16, 28)});

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var k = 0; k < children.length; k++) {
      if (k > 0) rows.add(Divider(height: 0.5, thickness: 0.5, indent: indent, color: sysSep(context)));
      rows.add(children[k]);
    }
    return Padding(
      padding: margin,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (header != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 7),
            child: Text(header!.toUpperCase(), style: TextStyle(fontSize: 13, letterSpacing: -0.1, color: sysLabel2(context))),
          ),
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Container(
            color: sysCard(context),
            child: Material(color: Colors.transparent, child: Column(children: rows)),
          ),
        ),
      ]),
    );
  }
}

class Cell extends StatelessWidget {
  final Widget? leading;
  final String title;
  final Widget? subtitle;
  final String? value;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color? titleColor;
  final bool chevron, center;
  final double minHeight;
  const Cell({
    super.key,
    required this.title,
    this.leading,
    this.subtitle,
    this.value,
    this.trailing,
    this.onTap,
    this.titleColor,
    this.chevron = false,
    this.center = false,
    this.minHeight = 44,
  });

  @override
  Widget build(BuildContext context) {
    final titleW = Text(title,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        textAlign: center ? TextAlign.center : TextAlign.start,
        style: TextStyle(fontSize: 17, letterSpacing: -0.4, color: titleColor));
    final body = Row(children: [
      if (leading != null) ...[leading!, const SizedBox(width: 12)],
      if (center)
        Expanded(child: titleW)
      else if (value != null) ...[
        titleW,
        const SizedBox(width: 12),
        Expanded(
          child: Text(value!,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 17, letterSpacing: -0.4, color: sysLabel2(context))),
        ),
      ] else
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            titleW,
            if (subtitle != null)
              DefaultTextStyle(
                style: TextStyle(fontSize: 14, letterSpacing: -0.2, color: sysLabel2(context)),
                child: Padding(padding: const EdgeInsets.only(top: 2), child: subtitle!),
              ),
          ]),
        ),
      if (trailing != null) ...[const SizedBox(width: 8), trailing!],
      if (chevron) ...[
        const SizedBox(width: 4),
        Icon(Icons.chevron_right_rounded, size: 24, color: isDark(context) ? const Color(0x4DEBEBF5) : const Color(0x4D3C3C43)),
      ],
    ]);
    return InkWell(
      onTap: onTap,
      child: ConstrainedBox(
        constraints: BoxConstraints(minHeight: minHeight),
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: body),
      ),
    );
  }
}

/// iOS Settings uslubidagi rangli kvadrat ikonka.
class IconTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  const IconTile(this.icon, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 29, height: 29,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(7)),
        child: Icon(icon, size: 18, color: Colors.white),
      );
}

// ---------------------------------------------------------------------
//  Action Sheet va Alert (dialog) uslublari
// ---------------------------------------------------------------------

/// iOS Action Sheet: yumaloq yarim shaffof blok + alohida "Bekor qilish" tugmasi.
Widget actionSheet(BuildContext sheetCtx, List<Widget> rows) {
  return SafeArea(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Glass(
          radius: 14, blur: 30,
          child: Material(
            color: Colors.transparent,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (var k = 0; k < rows.length; k++) ...[
                if (k > 0) Divider(height: 0.5, thickness: 0.5, color: sysSep(sheetCtx)),
                rows[k],
              ],
            ]),
          ),
        ),
        const SizedBox(height: 8),
        Glass(
          radius: 14, blur: 0,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => Navigator.pop(sheetCtx),
              child: SizedBox(
                height: 56,
                child: Center(
                  child: Text(t('cancel'), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: sysBlue(sheetCtx))),
                ),
              ),
            ),
          ),
        ),
      ]),
    ),
  );
}

/// iOS Alert tugmalar qatori: yuqorida ingichka chiziq, orasida vertikal chiziq.
class AlertButtons extends StatelessWidget {
  final String left, right;
  final VoidCallback onLeft, onRight;
  final Color? leftColor;
  const AlertButtons({super.key, required this.left, required this.right, required this.onLeft, required this.onRight, this.leftColor});

  @override
  Widget build(BuildContext context) {
    final sep = sysSep(context);
    Widget btn(String s, VoidCallback f, Color c, FontWeight w) => Expanded(
          child: InkWell(
            onTap: f,
            child: SizedBox(height: 46, child: Center(child: Text(s, style: TextStyle(fontSize: 17, fontWeight: w, color: c)))),
          ),
        );
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Divider(height: 0.5, thickness: 0.5, color: sep),
      Material(
        color: Colors.transparent,
        child: IntrinsicHeight(
          child: Row(children: [
            btn(left, onLeft, leftColor ?? sysBlue(context), FontWeight.w400),
            VerticalDivider(width: 0.5, thickness: 0.5, color: sep),
            btn(right, onRight, sysBlue(context), FontWeight.w600),
          ]),
        ),
      ),
    ]);
  }
}
