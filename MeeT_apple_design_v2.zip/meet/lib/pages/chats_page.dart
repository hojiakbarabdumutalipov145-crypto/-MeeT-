import 'package:flutter/cupertino.dart' show CupertinoActivityIndicator;
import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';
import 'chat_page.dart';

class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  late Future<List<Map<String, dynamic>>> f = _load();
  String q = '';

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await sb.from('chat_members').select('chats(id,type,title,created_by)').eq('user_id', me);
    final out = <Map<String, dynamic>>[];
    for (final r in rows) {
      final c = Map<String, dynamic>.from(r['chats'] as Map);
      if (c['type'] == 'direct') {
        final o = await sb.from('chat_members').select('user_id,profiles(name,username,avatar_url)')
            .eq('chat_id', c['id']).neq('user_id', me).maybeSingle();
        final pr = o?['profiles'] as Map?;
        c['title'] = pr?['name'] ?? pr?['username'] ?? '?';
        c['avatar'] = pr?['avatar_url'];
        c['peer'] = o?['user_id'];
      }
      out.add(c);
    }
    return out;
  }

  void _reload() => setState(() => f = _load());

  Future<void> _newDirect() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    if (p['id'] == me) return;
    try {
      await sb.rpc('create_direct_chat', params: {'other': p['id']});
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    _reload();
  }

  Future<void> _newGroup(String type) async {
    final title = await ask(context, t('title'));
    if (title == null || title.isEmpty) return;
    final c = await sb.from('chats').insert({'type': type, 'title': title, 'created_by': me}).select().single();
    await sb.from('chat_members').insert({'chat_id': c['id'], 'user_id': me});
    _reload();
  }

  void _sheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (d) => actionSheet(d, [
        Cell(leading: Icon(Icons.person_add_alt_1_outlined, color: sysBlue(d)), title: t('newDirect'), minHeight: 56, onTap: () { Navigator.pop(d); _newDirect(); }),
        Cell(leading: Icon(Icons.group_add_outlined, color: sysBlue(d)), title: t('newGroup'), minHeight: 56, onTap: () { Navigator.pop(d); _newGroup('group'); }),
        Cell(leading: Icon(Icons.campaign_outlined, color: sysBlue(d)), title: t('newChannel'), minHeight: 56, onTap: () { Navigator.pop(d); _newGroup('channel'); }),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = LargeTitle(t('chats'));
    final head = [
      AppHeader(actionIcon: Icons.edit_rounded, onAction: _sheet),
      title,
      SearchField(hint: t('search'), onChanged: (v) => setState(() => q = v.trim().toLowerCase())),
    ];
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: f,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) {
              return Column(children: [...head, const Expanded(child: Center(child: CupertinoActivityIndicator()))]);
            }
            if (s.hasError) return ListView(children: [...head, Center(child: Text('${s.error}'))]);
            final all = s.data!;
            final list = q.isEmpty ? all : all.where((c) => (c['title'] ?? '').toString().toLowerCase().contains(q)).toList();
            return ListView(padding: const EdgeInsets.only(bottom: 110), children: [
              ...head,
              if (q.isEmpty)
                PromoBanner(
                  icon: Icons.group_add_rounded,
                  title: t('bannerTitle'),
                  subtitle: t('bannerSub'),
                  onTap: () => _newGroup('group'),
                ),
              if (list.isEmpty)
                SizedBox(height: 240, child: Center(child: Text(t('noChats'), style: TextStyle(color: sysLabel2(context)))))
              else
                Group(
                  indent: 76,
                  children: [
                    for (final c in list)
                      Cell(
                        minHeight: 64,
                        leading: c['type'] == 'channel' || c['type'] == 'group'
                            ? Container(
                                width: 48, height: 48,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: c['type'] == 'channel' ? const [Color(0xFFFFB340), kOrange] : const [Color(0xFF5BD778), kGreen]),
                                ),
                                child: Icon(c['type'] == 'channel' ? Icons.campaign_rounded : Icons.group_rounded, color: Colors.white, size: 26),
                              )
                            : avatar(c['avatar'], c['title'] ?? ''),
                        title: c['title'] ?? '',
                        chevron: true,
                        onTap: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chat: c)));
                          _reload();
                        },
                      ),
                  ],
                ),
            ]);
          },
        ),
      ),
    );
  }
}
