import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'core.dart';
import 'glass.dart';
import 'widgets.dart';

const kMaxUpload = 50 * 1024 * 1024; // Supabase bepul tarifi chegarasi

String fmtSecs(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';

bool get isMobile => Platform.isAndroid || Platform.isIOS;

/// Fayl nomidan xavfsiz kengaytma ajratadi (faqat a-z0-9, 8 belgigacha).
String safeExt(String name, String fallback) {
  if (!name.contains('.')) return fallback;
  final e = name.split('.').last.toLowerCase();
  return RegExp(r'^[a-z0-9]{1,8}$').hasMatch(e) ? e : fallback;
}

// ---------- Yuklash va ssilka ----------

final _rnd = Random.secure();

/// Faylni `media` bucketiga `<chat_id>/<tasodifiy>.<ext>` yoʻli bilan yuklaydi.
Future<String> uploadMedia(String chatId, Uint8List bytes, String ext, String contentType) async {
  final id = List.generate(12, (_) => _rnd.nextInt(16).toRadixString(16)).join();
  final path = '$chatId/${DateTime.now().millisecondsSinceEpoch}_$id.$ext';
  await sb.storage.from('media').uploadBinary(path, bytes, fileOptions: FileOptions(contentType: contentType));
  return path;
}

final _urlCache = <String, (String, DateTime)>{};

/// Yopiq bucket uchun vaqtinchalik (1 soat) imzolangan ssilka; keshlanadi.
Future<String> mediaUrl(String path) async {
  final c = _urlCache[path];
  if (c != null && c.$2.isAfter(DateTime.now())) return c.$1;
  final u = await sb.storage.from('media').createSignedUrl(path, 3600);
  _urlCache[path] = (u, DateTime.now().add(const Duration(minutes: 50)));
  return u;
}

Future<void> openExternal(BuildContext c, String path) async {
  try {
    await launchUrl(Uri.parse(await mediaUrl(path)), mode: LaunchMode.externalApplication);
  } catch (e) {
    if (c.mounted) snack(c, '$e');
  }
}

// ---------- Rasm ----------

class ChatImage extends StatefulWidget {
  final String path;
  const ChatImage({super.key, required this.path});
  @override
  State<ChatImage> createState() => _ChatImageState();
}

class _ChatImageState extends State<ChatImage> {
  late final Future<String> f = mediaUrl(widget.path);

  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: f,
        builder: (c, s) {
          if (s.hasError) return const SizedBox(width: 220, height: 150, child: Center(child: Icon(Icons.broken_image_outlined)));
          if (!s.hasData) return const SizedBox(width: 220, height: 150, child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
          final url = s.data!;
          return GestureDetector(
            onTap: () => Navigator.push(
              c,
              MaterialPageRoute(
                builder: (_) => Scaffold(
                  backgroundColor: Colors.black,
                  appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
                  body: Center(child: InteractiveViewer(maxScale: 5, child: Image.network(url))),
                ),
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 240, maxHeight: 320),
                child: Image.network(
                  url,
                  fit: BoxFit.cover,
                  loadingBuilder: (_, w, p) => p == null ? w : const SizedBox(width: 220, height: 150, child: Center(child: CircularProgressIndicator(strokeWidth: 2))),
                  errorBuilder: (_, __, ___) => const SizedBox(width: 220, height: 150, child: Center(child: Icon(Icons.broken_image_outlined))),
                ),
              ),
            ),
          );
        },
      );
}

// ---------- Fayl ----------

class FileTile extends StatelessWidget {
  final String path, name;
  final bool mine;
  const FileTile({super.key, required this.path, required this.name, required this.mine});

  @override
  Widget build(BuildContext context) {
    final col = mine ? Colors.white : null;
    return InkWell(
      onTap: () => openExternal(context, path),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 180, maxWidth: 240),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(shape: BoxShape.circle, color: (mine ? Colors.white : kBlue).withOpacity(0.2)),
            child: Icon(Icons.insert_drive_file_outlined, color: mine ? Colors.white : kBlue),
          ),
          const SizedBox(width: 10),
          Flexible(child: Text(name.isEmpty ? 'file' : name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: col, fontWeight: FontWeight.w600))),
        ]),
      ),
    );
  }
}

// ---------- Ovozli xabar ----------

class VoiceBubble extends StatefulWidget {
  final String path;
  final int secs;
  final bool mine;
  const VoiceBubble({super.key, required this.path, required this.secs, required this.mine});
  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  final player = AudioPlayer();
  bool playing = false, started = false, loading = false;
  Duration pos = Duration.zero, total = Duration.zero;
  final subs = <StreamSubscription>[];

  @override
  void initState() {
    super.initState();
    total = Duration(seconds: widget.secs);
    subs.add(player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => playing = s == PlayerState.playing);
    }));
    subs.add(player.onPositionChanged.listen((p) {
      if (mounted) setState(() => pos = p);
    }));
    subs.add(player.onDurationChanged.listen((d) {
      if (mounted && d.inMilliseconds > 0) setState(() => total = d);
    }));
    subs.add(player.onPlayerComplete.listen((_) {
      if (mounted) setState(() { pos = Duration.zero; playing = false; started = false; });
    }));
  }

  @override
  void dispose() {
    for (final s in subs) { s.cancel(); }
    player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (loading) return;
    try {
      if (playing) {
        await player.pause();
      } else if (started) {
        await player.resume();
      } else {
        setState(() => loading = true);
        final url = await mediaUrl(widget.path);
        await player.play(UrlSource(url));
        started = true;
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final col = widget.mine ? Colors.white : kBlue;
    final totalMs = total.inMilliseconds;
    final v = totalMs <= 0 ? 0.0 : (pos.inMilliseconds / totalMs).clamp(0.0, 1.0);
    final shown = playing || pos > Duration.zero ? pos.inSeconds : total.inSeconds;
    return SizedBox(
      width: 210,
      child: Row(children: [
        GestureDetector(
          onTap: _toggle,
          child: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(shape: BoxShape.circle, color: col.withOpacity(0.2)),
            child: loading
                ? Padding(padding: const EdgeInsets.all(11), child: CircularProgressIndicator(strokeWidth: 2, color: col))
                : Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: col, size: 26),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(value: v, minHeight: 4, color: col, backgroundColor: col.withOpacity(0.25)),
          ),
        ),
        const SizedBox(width: 10),
        Text(fmtSecs(shown), style: TextStyle(fontSize: 12, color: widget.mine ? Colors.white70 : Colors.grey)),
      ]),
    );
  }
}

// ---------- Dumaloq video xabar ----------

class VideoNote extends StatefulWidget {
  final String path;
  final bool mine;
  const VideoNote({super.key, required this.path, required this.mine});
  @override
  State<VideoNote> createState() => _VideoNoteState();
}

class _VideoNoteState extends State<VideoNote> {
  VideoPlayerController? vc;
  bool loading = false;
  static const size = 210.0;

  @override
  void dispose() {
    vc?.dispose();
    super.dispose();
  }

  Future<void> _tap() async {
    if (!isMobile) {
      openExternal(context, widget.path); // Windows: tashqi pleyerda ochiladi
      return;
    }
    final c = vc;
    if (c == null) {
      setState(() => loading = true);
      try {
        final n = VideoPlayerController.networkUrl(Uri.parse(await mediaUrl(widget.path)));
        await n.initialize();
        n.addListener(() { if (mounted) setState(() {}); });
        vc = n;
        await n.play();
      } catch (e) {
        if (mounted) snack(context, '$e');
      }
      if (mounted) setState(() => loading = false);
    } else if (c.value.isPlaying) {
      await c.pause();
    } else {
      if (c.value.position >= c.value.duration) await c.seekTo(Duration.zero);
      await c.play();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = vc;
    final ready = c != null && c.value.isInitialized;
    final playing = ready && c.value.isPlaying;
    return GestureDetector(
      onTap: _tap,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withOpacity(0.8), width: 2),
          boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 6))],
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF5B9BFF), kBlue, kCyan]),
        ),
        child: ClipOval(
          child: Stack(alignment: Alignment.center, children: [
            if (ready)
              FittedBox(
                fit: BoxFit.cover,
                clipBehavior: Clip.hardEdge,
                child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)),
              ),
            if (loading)
              const CircularProgressIndicator(color: Colors.white)
            else if (!playing)
              Container(
                width: 54, height: 54,
                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withOpacity(0.35)),
                child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 36),
              ),
          ]),
        ),
      ),
    );
  }
}
