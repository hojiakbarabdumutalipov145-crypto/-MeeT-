import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  late Future<List<Map<String, dynamic>>> f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final r = await sb
        .from('calls')
        .select('*, caller:profiles!calls_caller_id_fkey(name), callee:profiles!calls_callee_id_fkey(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(r);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('calls'), style: const TextStyle(fontWeight: FontWeight.w800))),
      body: RefreshIndicator(
        onRefresh: () async => setState(() => f = _load()),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: f,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (s.hasError) return Center(child: Text('${s.error}'));
            final list = s.data!;
            if (list.isEmpty) return ListView(children: [SizedBox(height: 300, child: Center(child: Text(t('noCalls'))))]);
            return ListView.builder(
              itemCount: list.length,
              itemBuilder: (_, k) {
                final c = list[k];
                final out = c['caller_id'] == me;
                final name = (out ? c['callee'] : c['caller'])?['name'] ?? '?';
                final peerId = out ? c['callee_id'] : c['caller_id'];
                final missed = !out && c['status'] == 'missed';
                final d = DateTime.parse(c['created_at']).toLocal();
                final when = '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')} '
                    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
                return Glass(radius: 24, blur: 0, margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5), child: Material(color: Colors.transparent, child: ListTile(
                  leading: avatar(null, name),
                  title: Text(name, style: TextStyle(fontWeight: FontWeight.w600, color: missed ? Colors.red : null)),
                  subtitle: Row(children: [
                    Icon(out ? Icons.call_made : (missed ? Icons.call_missed : Icons.call_received), size: 16, color: missed ? Colors.red : Colors.green),
                    const SizedBox(width: 4),
                    Text(missed ? '${t('missed')} · $when' : when),
                  ]),
                  trailing: IconButton(
                    icon: Icon(c['kind'] == 'video' ? Icons.videocam : Icons.call, color: kBlue),
                    onPressed: () => startCall(context, peerId, name, c['kind']),
                  ),
                )));
              },
            );
          },
        ),
      ),
    );
  }
}
