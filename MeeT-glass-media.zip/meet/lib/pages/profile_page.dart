import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<String, dynamic>? p;
  final name = TextEditingController(), bio = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await sb.from('profiles').select().eq('id', me).single();
    name.text = r['name'] ?? '';
    bio.text = r['bio'] ?? '';
    if (mounted) setState(() => p = r);
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 85);
    if (x == null) return;
    try {
      final bytes = await x.readAsBytes();
      await sb.storage.from('avatars').uploadBinary('$me.jpg', bytes,
          fileOptions: const FileOptions(upsert: true, contentType: 'image/jpeg'));
      final url = '${sb.storage.from('avatars').getPublicUrl('$me.jpg')}?t=${DateTime.now().millisecondsSinceEpoch}';
      await sb.from('profiles').update({'avatar_url': url}).eq('id', me);
      _load();
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _save() async {
    await sb.from('profiles').update({'name': name.text.trim(), 'bio': bio.text.trim()}).eq('id', me);
    if (mounted) snack(context, t('saved'));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('profile'), style: const TextStyle(fontWeight: FontWeight.w800))),
      body: p == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(20), children: [
              Center(
                child: Stack(children: [
                  avatar(p!['avatar_url'], p!['name'] ?? '', r: 58),
                  Positioned(
                    right: 0, bottom: 0,
                    child: CircleAvatar(radius: 18, backgroundColor: kBlue, child: IconButton(padding: EdgeInsets.zero, icon: const Icon(Icons.camera_alt, size: 18, color: Colors.white), onPressed: _pick)),
                  ),
                ]),
              ),
              const SizedBox(height: 12),
              Center(child: Text('@${p!['username']}', style: const TextStyle(color: Colors.grey, fontSize: 16))),
              const SizedBox(height: 24),
              TextField(controller: name, decoration: InputDecoration(labelText: t('name'), prefixIcon: const Icon(Icons.badge_outlined))),
              const SizedBox(height: 12),
              TextField(controller: bio, maxLines: 3, decoration: InputDecoration(labelText: t('bio'), prefixIcon: const Icon(Icons.info_outline))),
              const SizedBox(height: 20),
              FilledButton(onPressed: _save, child: Text(t('save'))),
            ]),
    );
  }
}
