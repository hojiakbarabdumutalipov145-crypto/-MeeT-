import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';
import 'chat_page.dart';

class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  late Future<List<Map<String, dynamic>>> f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await sb.from('chat_members').select('chats(id,type,title,created_by)').eq('user_id', me);
    final out = <Map<String, dynamic>>[];
    for (final r in rows) {
      final c = Map<String, dynamic>.from(r['chats'] as Map);
      if (c['type'] == 'direct') {
        final o = await sb.from('chat_members').select('user_id,profiles(name,username,avatar_url)')
            .eq('chat_id', c['id']).neq('user_id', me).maybeSingle();
        final pr = o?['profiles'] as Map?;
        c['title'] = pr?['name'] ?? pr?['username'] ?? '?';
        c['avatar'] = pr?['avatar_url'];
        c['peer'] = o?['user_id'];
      }
      out.add(c);
    }
    return out;
  }

  void _reload() => setState(() => f = _load());

  Future<void> _newDirect() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    if (p['id'] == me) return;
    try {
      await sb.rpc('create_direct_chat', params: {'other': p['id']});
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    _reload();
  }

  Future<void> _newGroup(String type) async {
    final title = await ask(context, t('title'));
    if (title == null || title.isEmpty) return;
    final c = await sb.from('chats').insert({'type': type, 'title': title, 'created_by': me}).select().single();
    await sb.from('chat_members').insert({'chat_id': c['id'], 'user_id': me});
    _reload();
  }

  void _sheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (d) => SafeArea(
        child: Glass(radius: 30, margin: const EdgeInsets.fromLTRB(14, 0, 14, 14), padding: const EdgeInsets.symmetric(vertical: 8), child: Material(color: Colors.transparent, child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.person_add_alt_1), title: Text(t('newDirect')), onTap: () { Navigator.pop(d); _newDirect(); }),
          ListTile(leading: const Icon(Icons.group_add), title: Text(t('newGroup')), onTap: () { Navigator.pop(d); _newGroup('group'); }),
          ListTile(leading: const Icon(Icons.campaign), title: Text(t('newChannel')), onTap: () { Navigator.pop(d); _newGroup('channel'); }),
        ]))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/logo.png', width: 30)),
          const SizedBox(width: 10),
          const Text('MeeT', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
      ),
      floatingActionButton: FloatingActionButton(onPressed: _sheet, elevation: 0, backgroundColor: kBlue, foregroundColor: Colors.white, shape: const CircleBorder(side: BorderSide(color: Colors.white54, width: 1.2)), child: const Icon(Icons.edit)),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: f,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (s.hasError) return Center(child: Text('${s.error}'));
            final list = s.data!;
            if (list.isEmpty) return ListView(children: [SizedBox(height: 300, child: Center(child: Text(t('noChats'))))]);
            return ListView.builder(
              itemCount: list.length,
              itemBuilder: (_, k) {
                final c = list[k];
                final icon = c['type'] == 'channel' ? Icons.campaign : c['type'] == 'group' ? Icons.group : null;
                return Glass(
                  radius: 24, blur: 0,
                  margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  child: Material(
                    color: Colors.transparent,
                    child: ListTile(
                      leading: icon != null
                          ? CircleAvatar(radius: 24, backgroundColor: kBlue.withOpacity(0.2), child: Icon(icon, color: kBlue))
                          : avatar(c['avatar'], c['title'] ?? ''),
                      title: Text(c['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chat: c)));
                        _reload();
                      },
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
