import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _setTheme(ThemeMode m) async {
    themeMode.value = m;
    (await SharedPreferences.getInstance()).setInt('theme', m.index);
  }

  Future<void> _setLang(String l) async {
    (await SharedPreferences.getInstance()).setString('lang', l);
    appLocale.value = l;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('settings'), style: const TextStyle(fontWeight: FontWeight.w800))),
      body: ListView(children: [
        ListTile(
          leading: const Icon(Icons.account_circle_outlined), title: Text(t('account')), trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountPage())),
        ),
        ListTile(
          leading: const Icon(Icons.lock_outline), title: Text(t('privacy')), trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPage())),
        ),
        const Divider(),
        ListTile(leading: const Icon(Icons.palette_outlined), title: Text(t('theme'))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ValueListenableBuilder<ThemeMode>(
            valueListenable: themeMode,
            builder: (_, m, __) => SegmentedButton<ThemeMode>(
              segments: [
                ButtonSegment(value: ThemeMode.light, icon: const Icon(Icons.light_mode), label: Text(t('light'))),
                ButtonSegment(value: ThemeMode.dark, icon: const Icon(Icons.dark_mode), label: Text(t('dark'))),
                ButtonSegment(value: ThemeMode.system, icon: const Icon(Icons.phone_android), label: Text(t('system'))),
              ],
              selected: {m},
              onSelectionChanged: (s) => _setTheme(s.first),
            ),
          ),
        ),
        const Divider(),
        ListTile(leading: const Icon(Icons.language), title: Text(t('language'))),
        for (final e in langNames.entries)
          ListTile(
            contentPadding: const EdgeInsets.only(left: 72, right: 16),
            title: Text(e.value),
            trailing: appLocale.value == e.key ? const Icon(Icons.check_circle, color: kBlue) : null,
            onTap: () => _setLang(e.key),
          ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: Text(t('logout'), style: const TextStyle(color: Colors.red)),
          onTap: () => sb.auth.signOut(),
        ),
      ]),
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('account'))),
      body: FutureBuilder<Map<String, dynamic>>(
        future: sb.from('profiles').select().eq('id', me).single(),
        builder: (_, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final p = s.data!;
          return ListView(children: [
            Padding(padding: const EdgeInsets.all(20), child: Center(child: avatar(p['avatar_url'], p['name'] ?? '', r: 46))),
            ListTile(title: Text(t('name')), subtitle: Text(p['name'] ?? '')),
            ListTile(title: Text(t('username')), subtitle: Text('@${p['username']}')),
            ListTile(title: Text(t('bio')), subtitle: Text(p['bio'] ?? '')),
            ListTile(title: Text(t('joined')), subtitle: Text(p['created_at'].toString().substring(0, 10))),
            ListTile(title: Text(t('userId')), subtitle: Text(p['id'])),
          ]);
        },
      ),
    );
  }
}

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  Future<void> _changeUsername(BuildContext c) async {
    final v = (await ask(c, t('newUsername')))?.toLowerCase();
    if (v == null || v.isEmpty) return;
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(v)) { snack(c, t('badUsername')); return; }
    final oldEmail = sb.auth.currentUser?.email;
    try {
      final taken = await sb.from('profiles').select('id').eq('username', v).neq('id', me).maybeSingle();
      if (taken != null) { if (c.mounted) snack(c, t('taken')); return; }
      // Avval kirish emaili, keyin profil: ikkalasi bir xil boʻlmasa oʻzgartirilmaydi
      final res = await sb.auth.updateUser(UserAttributes(email: '$v@meet.app'));
      if (res.user?.email != '$v@meet.app') {
        if (c.mounted) snack(c, t('usernameFail'));
        return;
      }
      try {
        await sb.from('profiles').update({'username': v}).eq('id', me);
      } catch (e) {
        if (oldEmail != null) { try { await sb.auth.updateUser(UserAttributes(email: oldEmail)); } catch (_) {} }
        rethrow;
      }
      if (c.mounted) snack(c, t('saved'));
    } catch (e) {
      if (c.mounted) snack(c, '$e');
    }
  }

  Future<void> _changePassword(BuildContext c) async {
    final v = await ask(c, t('newPassword'), obscure: true);
    if (v == null || v.isEmpty) return;
    if (v.length < 6) { snack(c, t('badPassword')); return; }
    try {
      await sb.auth.updateUser(UserAttributes(password: v));
      if (c.mounted) snack(c, t('saved'));
    } catch (e) {
      if (c.mounted) snack(c, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('privacy'))),
      body: ListView(children: [
        ListTile(leading: const Icon(Icons.alternate_email), title: Text(t('newUsername')), onTap: () => _changeUsername(context)),
        ListTile(leading: const Icon(Icons.password), title: Text(t('newPassword')), onTap: () => _changePassword(context)),
      ]),
    );
  }
}
