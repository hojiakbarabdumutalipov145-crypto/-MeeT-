// Supabase loyihangizdan oling: Project Settings -> API
const kSupabaseUrl = 'https://kcfzkbnimhgjpvarpanm.supabase.co';
const kSupabaseAnonKey = 'sb_publishable_qlVC-u8kobo-2pbfMiWGAQ_peTePa45';

// Qoʻngʻiroq butun dunyoda ishlashi uchun TURN server kerak (coturn yoki Metered/Twilio).
const kIceConfig = {
  'iceServers': [
    {'urls': 'stun:stun.l.google.com:19302'},
    // {'urls': 'turn:turn.example.com:3478', 'username': 'user', 'credential': 'pass'},
  ],
};
