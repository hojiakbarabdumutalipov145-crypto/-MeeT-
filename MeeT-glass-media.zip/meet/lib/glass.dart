import 'dart:ui';
import 'package:flutter/material.dart';
import 'core.dart';

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

/// Butun ilova orqasidagi yorugʻ "aurora" fon (Liquid Glass uchun asos).
class Aurora extends StatelessWidget {
  final Widget child;
  const Aurora({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    Widget blob(Color c, double s) => IgnorePointer(
          child: Container(
            width: s, height: s,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [c.withOpacity(d ? 0.55 : 0.42), c.withOpacity(0)]),
            ),
          ),
        );
    return Stack(children: [
      Positioned.fill(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: d
                  ? const [kNavy, Color(0xFF0B1A5C), Color(0xFF061029)]
                  : const [Color(0xFFE8F0FF), Color(0xFFF1ECFF), Color(0xFFE4FAFF)],
            ),
          ),
        ),
      ),
      Positioned(top: -120, left: -110, child: blob(kBlue, 390)),
      Positioned(top: 280, right: -170, child: blob(const Color(0xFF8B5CF6), 430)),
      Positioned(bottom: -150, left: -70, child: blob(kCyan, 390)),
      Positioned.fill(child: child),
    ]);
  }
}

/// Shisha panel: xiralashtirish + yorugʻlik gradienti + nozik oq hoshiya.
class Glass extends StatelessWidget {
  final Widget child;
  final double radius, blur;
  final EdgeInsetsGeometry? padding, margin;
  final Gradient? tint;
  const Glass({super.key, required this.child, this.radius = 22, this.blur = 18, this.padding, this.margin, this.tint});

  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    final br = BorderRadius.circular(radius);
    Widget panel = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: br,
        gradient: tint ??
            LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [Colors.white.withOpacity(d ? 0.17 : 0.72), Colors.white.withOpacity(d ? 0.05 : 0.32)],
            ),
        border: Border.all(color: Colors.white.withOpacity(d ? 0.24 : 0.85), width: 1),
      ),
      child: child,
    );
    if (blur > 0) {
      panel = BackdropFilter(filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur), child: panel);
    }
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: br,
        boxShadow: [BoxShadow(color: (d ? Colors.black : kBlue).withOpacity(d ? 0.35 : 0.12), blurRadius: 26, offset: const Offset(0, 10))],
      ),
      child: ClipRRect(borderRadius: br, child: panel),
    );
  }
}

/// Shisha AppBar fon qatlami: AppBar(flexibleSpace: glassBar())
Widget glassBar() => const _GlassBar();

class _GlassBar extends StatelessWidget {
  const _GlassBar();
  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(d ? 0.07 : 0.45),
            border: Border(bottom: BorderSide(color: Colors.white.withOpacity(d ? 0.18 : 0.8))),
          ),
        ),
      ),
    );
  }
}

class NavItem {
  final IconData icon, activeIcon;
  final String label;
  const NavItem(this.icon, this.activeIcon, this.label);
}

/// Bubble uslubidagi pastki menyu: tanlangan band pufakcha boʻlib koʻtariladi.
class BubbleNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  final List<NavItem> items;
  const BubbleNav({super.key, required this.index, required this.onTap, required this.items});

  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
        child: Glass(
          radius: 36, blur: 24,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(children: [
            for (var k = 0; k < items.length; k++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(k),
                  child: _bubble(items[k], k == index, d),
                ),
              ),
          ]),
        ),
      ),
    );
  }

  Widget _bubble(NavItem it, bool on, bool d) => AnimatedContainer(
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutBack,
        padding: const EdgeInsets.symmetric(vertical: 6),
        transform: Matrix4.translationValues(0, on ? -6 : 0, 0),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 380),
            curve: Curves.easeOutBack,
            width: on ? 52 : 44, height: on ? 52 : 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: on
                    ? const [Color(0xFF5B9BFF), kBlue, kCyan]
                    : [Colors.white.withOpacity(0), Colors.white.withOpacity(0)],
              ),
              border: Border.all(color: Colors.white.withOpacity(on ? 0.7 : 0), width: 1.2),
              boxShadow: on ? [BoxShadow(color: kBlue.withOpacity(0.55), blurRadius: 18, offset: const Offset(0, 6))] : [],
            ),
            child: Icon(on ? it.activeIcon : it.icon, size: on ? 26 : 24,
                color: on ? Colors.white : (d ? Colors.white70 : Colors.black54)),
          ),
          const SizedBox(height: 3),
          Text(it.label,
              style: TextStyle(fontSize: 11, fontWeight: on ? FontWeight.w700 : FontWeight.w500,
                  color: on ? kBlue : (d ? Colors.white60 : Colors.black45))),
        ]),
      );
}
