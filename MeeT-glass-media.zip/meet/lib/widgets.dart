import 'package:flutter/material.dart';
import 'core.dart';
import 'glass.dart';
import 'l10n.dart';
import 'pages/call_page.dart';

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

Future<String?> ask(BuildContext c, String title, {bool obscure = false}) {
  final ctl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (d) => Dialog(
      backgroundColor: Colors.transparent, elevation: 0,
      child: Glass(
        radius: 28, padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 14),
          TextField(controller: ctl, autofocus: true, obscureText: obscure),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: TextButton(onPressed: () => Navigator.pop(d), child: Text(t('cancel')))),
            Expanded(child: FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(90, 46)),
              onPressed: () => Navigator.pop(d, ctl.text.trim()),
              child: Text(t('save')),
            )),
          ]),
        ]),
      ),
    ),
  );
}

Future<void> startCall(BuildContext c, String peerId, String peerName, String kind) async {
  try {
    final r = await sb.from('calls').insert({'caller_id': me, 'callee_id': peerId, 'kind': kind}).select().single();
    if (!c.mounted) return;
    Navigator.push(c, MaterialPageRoute(
        builder: (_) => CallPage(callId: r['id'], caller: true, video: kind == 'video', peer: peerName)));
  } catch (e) {
    if (c.mounted) snack(c, '$e');
  }
}
