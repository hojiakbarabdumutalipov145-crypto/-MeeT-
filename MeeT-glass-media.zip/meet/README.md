# MeeT — messenjer (Flutter + Supabase + WebRTC)

Bitta kod: Android (APK) va Windows (EXE).

## Ishga tushirish
1. https://supabase.com da bepul loyiha oching.
2. Authentication → Providers → Email: **"Confirm email" ni oʻchiring** (login username@meet.app tarzida ishlaydi).
3. SQL Editor → `supabase/schema.sql` ni toʻliq joylab Run bosing.
4. `lib/config.dart` ga Project URL va anon key ni yozing (Project Settings → API).
5. GitHub'da yangi repo ochib, shu papkadagi hamma narsani yuklang (`.github` papkasi bilan).
6. Repo → Actions → "Build MeeT" → Run workflow. Tugagach Artifacts dan `MeeT-apk` va `MeeT-windows` ni yuklab oling.

## 1-bosqich tuzatishlari (fix1)
- Supabase SQL Editor'da `supabase/fix1.sql` ni **bir marta** ishga tushiring.
- GitHub -> Settings -> Secrets -> Actions: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_PASSWORD`, `KEY_ALIAS` ni qoʻshing (doimiy imzo; shunda APK ustiga yangilanadi).

## 2-bosqich (fix2) — media
- Supabase SQL Editor'da `supabase/fix2.sql` ni **bir marta** ishga tushiring (yopiq `media` bucket + siyosatlar).
- Ovozli xabar (mikrofon tugmasi), rasm, fayl (≤50 MB), dumaloq video (≤60 s) yuboriladi.

## Hozir ishlaydi
Akkaunt (kirish/roʻyxatdan oʻtish), chatlar (shaxsiy, guruh, kanal), matnli xabarlar real vaqtda,
audio/video qoʻngʻiroq (WebRTC), qoʻngʻiroqlar tarixi, sozlamalar (mavzu, 3 til, username/parol oʻzgartirish), profil + rasm.

## Keyingi bosqich (hali yoʻq)
- **Ilova yopiq paytda jiringlash**: Firebase Cloud Messaging + `flutter_callkit_incoming` (Android).
- **TURN server** (`config.dart`) — turli tarmoq/davlatlarda qoʻngʻiroq barqaror ishlashi uchun shart.
