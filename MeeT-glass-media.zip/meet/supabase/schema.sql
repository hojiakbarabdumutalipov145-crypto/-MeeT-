-- Supabase -> SQL Editor ga toʻliq nusxalab Run bosing
create table profiles(
  id uuid primary key references auth.users on delete cascade,
  username text unique not null, name text, bio text default '', avatar_url text,
  created_at timestamptz default now());
create table chats(
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('direct','group','channel')),
  title text, created_by uuid references profiles(id), created_at timestamptz default now());
create table chat_members(
  chat_id uuid references chats(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key(chat_id, user_id));
create table messages(
  id uuid primary key default gen_random_uuid(),
  chat_id uuid references chats(id) on delete cascade,
  sender_id uuid references profiles(id),
  type text default 'text', content text, media_url text,
  created_at timestamptz default now());
create table calls(
  id uuid primary key default gen_random_uuid(),
  caller_id uuid references profiles(id), callee_id uuid references profiles(id),
  kind text check (kind in ('audio','video')), status text default 'ringing',
  created_at timestamptz default now());

create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into profiles(id, username, name)
  values (new.id, new.raw_user_meta_data->>'username', new.raw_user_meta_data->>'name');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create function is_member(c uuid) returns boolean language sql security definer set search_path=public stable as $$
  select exists(select 1 from chat_members where chat_id=c and user_id=auth.uid()) $$;

alter table profiles enable row level security;
alter table chats enable row level security;
alter table chat_members enable row level security;
alter table messages enable row level security;
alter table calls enable row level security;

create policy p_sel on profiles for select to authenticated using (true);
create policy p_upd on profiles for update to authenticated using (id=auth.uid());

create policy c_sel on chats for select to authenticated using (created_by=auth.uid() or is_member(id));
create policy c_ins on chats for insert to authenticated with check (created_by=auth.uid());

create policy m_sel on chat_members for select to authenticated using (user_id=auth.uid() or is_member(chat_id));
create policy m_ins on chat_members for insert to authenticated with check (
  exists(select 1 from chats where id=chat_id and created_by=auth.uid()) or is_member(chat_id));

create policy msg_sel on messages for select to authenticated using (is_member(chat_id));
create policy msg_ins on messages for insert to authenticated with check (
  sender_id=auth.uid() and is_member(chat_id) and
  exists(select 1 from chats c where c.id=chat_id and (c.type<>'channel' or c.created_by=auth.uid())));

create policy call_sel on calls for select to authenticated using (caller_id=auth.uid() or callee_id=auth.uid());
create policy call_ins on calls for insert to authenticated with check (caller_id=auth.uid());
create policy call_upd on calls for update to authenticated using (caller_id=auth.uid() or callee_id=auth.uid());

alter publication supabase_realtime add table messages, calls;

insert into storage.buckets(id,name,public) values('avatars','avatars',true) on conflict do nothing;
create policy av_read on storage.objects for select using (bucket_id='avatars');
create policy av_ins on storage.objects for insert to authenticated with check (bucket_id='avatars' and name like auth.uid()::text || '%');
create policy av_upd on storage.objects for update to authenticated using (bucket_id='avatars' and name like auth.uid()::text || '%');
