-- 2-bosqich: ovozli xabar, dumaloq video, rasm va fayllar.
-- Supabase -> SQL Editor ga toʻliq joylab Run bosing (bir marta).

-- 1) Yopiq `media` bucket (50 MB gacha fayl). Ssilkalar ilovada vaqtincha imzolanadi.
insert into storage.buckets(id, name, public, file_size_limit)
values ('media', 'media', false, 52428800)
on conflict (id) do update set public = false, file_size_limit = 52428800;

-- 2) Fayl yoʻli: <chat_id>/<fayl>. Faqat shu chat aʼzosi oʻqiy oladi / yuklay oladi.
drop policy if exists media_read on storage.objects;
drop policy if exists media_ins on storage.objects;
create policy media_read on storage.objects for select to authenticated using (
  bucket_id = 'media' and is_member(((storage.foldername(name))[1])::uuid));
create policy media_ins on storage.objects for insert to authenticated with check (
  bucket_id = 'media'
  and is_member(((storage.foldername(name))[1])::uuid)
  and exists(select 1 from chats c
             where c.id = ((storage.foldername(name))[1])::uuid
               and (c.type <> 'channel' or c.created_by = auth.uid())));

-- 3) Xabar turi va media yoʻli serverda ham tekshiriladi
alter table messages drop constraint if exists messages_type_chk;
alter table messages add constraint messages_type_chk
  check (type in ('text', 'image', 'voice', 'video_note', 'file'));
alter table messages drop constraint if exists messages_media_chk;
alter table messages add constraint messages_media_chk
  check (media_url is null or media_url like chat_id::text || '/%');
