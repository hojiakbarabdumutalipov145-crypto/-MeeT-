-- 1-bosqich tuzatishlari. Supabase -> SQL Editor ga toʻliq joylab Run bosing (bir marta).

-- 1) Direct chat: dublikat yaratmaydi, hammasi bitta amalda (atomik)
create or replace function create_direct_chat(other uuid) returns uuid
language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if other = auth.uid() then raise exception 'cannot chat with yourself'; end if;
  select c.id into cid from chats c
   where c.type='direct'
     and exists(select 1 from chat_members m where m.chat_id=c.id and m.user_id=auth.uid())
     and exists(select 1 from chat_members m where m.chat_id=c.id and m.user_id=other)
   limit 1;
  if cid is not null then return cid; end if;
  insert into chats(type, created_by) values ('direct', auth.uid()) returning id into cid;
  insert into chat_members(chat_id, user_id) values (cid, auth.uid()), (cid, other);
  return cid;
end $$;
revoke all on function create_direct_chat(uuid) from public, anon;
grant execute on function create_direct_chat(uuid) to authenticated;

-- 2) Aʼzo qoʻshish: faqat guruh/kanal egasi (direct chatga begonani qoʻshib boʻlmaydi)
drop policy if exists m_ins on chat_members;
create policy m_ins on chat_members for insert to authenticated with check (
  exists(select 1 from chats where id=chat_id and created_by=auth.uid() and type<>'direct'));

-- 3) Qoʻngʻiroqda faqat status oʻzgara oladi
create or replace function calls_guard() returns trigger language plpgsql as $$
begin
  if new.caller_id<>old.caller_id or new.callee_id<>old.callee_id
     or new.kind<>old.kind or new.created_at<>old.created_at then
    raise exception 'only status can be changed';
  end if;
  return new;
end $$;
drop trigger if exists calls_guard_t on calls;
create trigger calls_guard_t before update on calls for each row execute function calls_guard();

-- 4) Profil: id ni almashtirib boʻlmaydi; username formati serverda ham tekshiriladi
drop policy if exists p_upd on profiles;
create policy p_upd on profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
alter table profiles drop constraint if exists username_fmt;
alter table profiles add constraint username_fmt check (username ~ '^[a-z0-9_]{3,20}$');
