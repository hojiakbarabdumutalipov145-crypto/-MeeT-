import 'package:flutter/cupertino.dart' show CupertinoActivityIndicator;
import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  late Future<List<Map<String, dynamic>>> f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final r = await sb
        .from('calls')
        .select('*, caller:profiles!calls_caller_id_fkey(name), callee:profiles!calls_callee_id_fkey(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(r);
  }

  @override
  Widget build(BuildContext context) {
    final title = LargeTitle(t('calls'));
    return Scaffold(
      appBar: AppBar(),
      body: RefreshIndicator(
        onRefresh: () async => setState(() => f = _load()),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: f,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) {
              return Column(children: [title, const Expanded(child: Center(child: CupertinoActivityIndicator()))]);
            }
            if (s.hasError) return ListView(children: [title, Center(child: Text('${s.error}'))]);
            final list = s.data!;
            if (list.isEmpty) {
              return ListView(children: [title, SizedBox(height: 300, child: Center(child: Text(t('noCalls'), style: TextStyle(color: sysLabel2(context)))))]);
            }
            return ListView(children: [
              title,
              Group(
                indent: 76,
                children: [
                  for (final c in list) _row(context, c),
                ],
              ),
            ]);
          },
        ),
      ),
    );
  }

  Widget _row(BuildContext context, Map<String, dynamic> c) {
    final out = c['caller_id'] == me;
    final name = (out ? c['callee'] : c['caller'])?['name'] ?? '?';
    final peerId = out ? c['callee_id'] : c['caller_id'];
    final missed = !out && c['status'] == 'missed';
    final d = DateTime.parse(c['created_at']).toLocal();
    final when = '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')} '
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return Cell(
      minHeight: 64,
      leading: avatar(null, name),
      title: name,
      titleColor: missed ? kRed : null,
      subtitle: Row(children: [
        Icon(out ? Icons.call_made_rounded : (missed ? Icons.call_missed_rounded : Icons.call_received_rounded), size: 15, color: missed ? kRed : kGray),
        const SizedBox(width: 4),
        Text(missed ? '${t('missed')} · $when' : when),
      ]),
      trailing: IconButton(
        icon: Icon(c['kind'] == 'video' ? Icons.videocam_outlined : Icons.call_outlined, color: sysBlue(context)),
        onPressed: () => startCall(context, peerId, name, c['kind']),
      ),
    );
  }
}
