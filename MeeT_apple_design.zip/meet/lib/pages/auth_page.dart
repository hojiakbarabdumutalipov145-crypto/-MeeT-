import 'package:flutter/cupertino.dart' show CupertinoActivityIndicator;
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../glass.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool signup = false, loading = false, hide = true;
  String? error;
  final u = TextEditingController(), p = TextEditingController(), n = TextEditingController();

  Future<void> submit() async {
    final user = u.text.trim().toLowerCase();
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(user)) return setState(() => error = t('badUsername'));
    if (p.text.length < 6) return setState(() => error = t('badPassword'));
    setState(() { loading = true; error = null; });
    try {
      final email = '$user@meet.app';
      if (signup) {
        await sb.auth.signUp(email: email, password: p.text, data: {
          'username': user,
          'name': n.text.trim().isEmpty ? user : n.text.trim(),
        });
      } else {
        await sb.auth.signInWithPassword(email: email, password: p.text);
      }
    } on AuthException catch (e) {
      error = e.message;
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(children: [
                ClipRRect(borderRadius: BorderRadius.circular(22), child: Image.asset('assets/logo.png', width: 96)),
                const SizedBox(height: 24),
                Text(signup ? t('signup') : t('signin'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: 0.36)),
                const SizedBox(height: 28),
                if (signup) ...[
                  TextField(controller: n, decoration: InputDecoration(labelText: t('name'), prefixIcon: const Icon(Icons.badge_outlined))),
                  const SizedBox(height: 12),
                ],
                TextField(controller: u, decoration: InputDecoration(labelText: t('username'), prefixIcon: const Icon(Icons.alternate_email))),
                const SizedBox(height: 12),
                TextField(
                  controller: p,
                  obscureText: hide,
                  onSubmitted: (_) => submit(),
                  decoration: InputDecoration(
                    labelText: t('password'),
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(hide ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: kGray),
                      onPressed: () => setState(() => hide = !hide),
                    ),
                  ),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: kRed, fontSize: 14)),
                  ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: loading ? null : submit,
                  child: loading
                      ? const CupertinoActivityIndicator(color: Colors.white)
                      : Text(signup ? t('signup') : t('signin')),
                ),
                const SizedBox(height: 4),
                TextButton(
                  onPressed: () => setState(() { signup = !signup; error = null; }),
                  child: Text(signup ? t('haveAcc') : t('noAcc')),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
