import 'package:flutter/cupertino.dart' show CupertinoActivityIndicator, CupertinoSlidingSegmentedControl;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _setTheme(ThemeMode m) async {
    themeMode.value = m;
    (await SharedPreferences.getInstance()).setInt('theme', m.index);
  }

  Future<void> _setLang(String l) async {
    (await SharedPreferences.getInstance()).setString('lang', l);
    appLocale.value = l;
  }

  @override
  Widget build(BuildContext context) {
    Widget seg(IconData i, String label) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(i, size: 16),
            const SizedBox(width: 5),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
          ]),
        );
    return Scaffold(
      appBar: AppBar(),
      body: ListView(children: [
        LargeTitle(t('settings')),
        Group(indent: 58, children: [
          Cell(
            leading: const IconTile(Icons.person_rounded, kBlue), title: t('account'), chevron: true,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountPage())),
          ),
          Cell(
            leading: const IconTile(Icons.lock_rounded, kGray), title: t('privacy'), chevron: true,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPage())),
          ),
        ]),
        Group(header: t('theme'), children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: ValueListenableBuilder<ThemeMode>(
              valueListenable: themeMode,
              builder: (_, m, __) => SizedBox(
                width: double.infinity,
                child: CupertinoSlidingSegmentedControl<ThemeMode>(
                  groupValue: m,
                  children: {
                    ThemeMode.light: seg(Icons.light_mode_rounded, t('light')),
                    ThemeMode.dark: seg(Icons.dark_mode_rounded, t('dark')),
                    ThemeMode.system: seg(Icons.phone_iphone_rounded, t('system')),
                  },
                  onValueChanged: (v) { if (v != null) _setTheme(v); },
                ),
              ),
            ),
          ),
        ]),
        Group(header: t('language'), children: [
          for (final e in langNames.entries)
            Cell(
              title: e.value,
              trailing: appLocale.value == e.key ? Icon(Icons.check_rounded, color: sysBlue(context)) : null,
              onTap: () => _setLang(e.key),
            ),
        ]),
        Group(children: [
          Cell(title: t('logout'), center: true, titleColor: kRed, onTap: () => sb.auth.signOut()),
        ]),
        const SizedBox(height: 90),
      ]),
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('account'))),
      body: FutureBuilder<Map<String, dynamic>>(
        future: sb.from('profiles').select().eq('id', me).single(),
        builder: (_, s) {
          if (!s.hasData) return const Center(child: CupertinoActivityIndicator());
          final p = s.data!;
          return ListView(children: [
            Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 24), child: Center(child: avatar(p['avatar_url'], p['name'] ?? '', r: 46))),
            Group(children: [
              Cell(title: t('name'), value: p['name'] ?? ''),
              Cell(title: t('username'), value: '@${p['username']}'),
              Cell(title: t('bio'), value: p['bio'] ?? ''),
              Cell(title: t('joined'), value: p['created_at'].toString().substring(0, 10)),
              Cell(title: t('userId'), value: p['id']),
            ]),
          ]);
        },
      ),
    );
  }
}

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  Future<void> _changeUsername(BuildContext c) async {
    final v = (await ask(c, t('newUsername')))?.toLowerCase();
    if (v == null || v.isEmpty) return;
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(v)) { snack(c, t('badUsername')); return; }
    final oldEmail = sb.auth.currentUser?.email;
    try {
      final taken = await sb.from('profiles').select('id').eq('username', v).neq('id', me).maybeSingle();
      if (taken != null) { if (c.mounted) snack(c, t('taken')); return; }
      // Avval kirish emaili, keyin profil: ikkalasi bir xil boʻlmasa oʻzgartirilmaydi
      final res = await sb.auth.updateUser(UserAttributes(email: '$v@meet.app'));
      if (res.user?.email != '$v@meet.app') {
        if (c.mounted) snack(c, t('usernameFail'));
        return;
      }
      try {
        await sb.from('profiles').update({'username': v}).eq('id', me);
      } catch (e) {
        if (oldEmail != null) { try { await sb.auth.updateUser(UserAttributes(email: oldEmail)); } catch (_) {} }
        rethrow;
      }
      if (c.mounted) snack(c, t('saved'));
    } catch (e) {
      if (c.mounted) snack(c, '$e');
    }
  }

  Future<void> _changePassword(BuildContext c) async {
    final v = await ask(c, t('newPassword'), obscure: true);
    if (v == null || v.isEmpty) return;
    if (v.length < 6) { snack(c, t('badPassword')); return; }
    try {
      await sb.auth.updateUser(UserAttributes(password: v));
      if (c.mounted) snack(c, t('saved'));
    } catch (e) {
      if (c.mounted) snack(c, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('privacy'))),
      body: ListView(children: [
        const SizedBox(height: 8),
        Group(indent: 58, children: [
          Cell(leading: const IconTile(Icons.alternate_email_rounded, kBlue), title: t('newUsername'), chevron: true, onTap: () => _changeUsername(context)),
          Cell(leading: const IconTile(Icons.key_rounded, kOrange), title: t('newPassword'), chevron: true, onTap: () => _changePassword(context)),
        ]),
      ]),
    );
  }
}
