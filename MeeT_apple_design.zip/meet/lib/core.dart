import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);
final appLocale = ValueNotifier<String>('uz');
SupabaseClient get sb => Supabase.instance.client;
String get me => sb.auth.currentUser!.id;

// ---- Apple Human Interface Guidelines ranglari (system colors) ----
const kBlue = Color(0xFF007AFF); // systemBlue
const kBlueDark = Color(0xFF0A84FF); // systemBlue (dark)
const kNavy = Color(0xFF020B3D);
const kCyan = Color(0xFF22D3EE);
const kRed = Color(0xFFFF3B30); // systemRed
const kGreen = Color(0xFF34C759); // systemGreen
const kOrange = Color(0xFFFF9500); // systemOrange
const kGray = Color(0xFF8E8E93); // systemGray

ThemeData buildTheme(Brightness b) {
  final d = b == Brightness.dark;
  final blue = d ? kBlueDark : kBlue;
  final bg = d ? Colors.black : const Color(0xFFF2F2F7); // systemGroupedBackground
  final card = d ? const Color(0xFF1C1C1E) : Colors.white; // secondarySystemGroupedBackground
  final label = d ? Colors.white : Colors.black;
  final sep = d ? const Color(0xFF38383A) : const Color(0xFFC6C6C8);
  final cs = ColorScheme.fromSeed(seedColor: kBlue, brightness: b).copyWith(
    primary: blue,
    onPrimary: Colors.white,
    surface: card,
    onSurface: label,
    error: d ? const Color(0xFFFF453A) : kRed,
  );
  const inputBorder = OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)), borderSide: BorderSide.none);
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    scaffoldBackgroundColor: bg,
    splashFactory: NoSplash.splashFactory,
    highlightColor: (d ? Colors.white : Colors.black).withOpacity(0.06),
    pageTransitionsTheme: PageTransitionsTheme(builders: {
      TargetPlatform.android: CupertinoPageTransitionsBuilder(),
      TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      TargetPlatform.windows: CupertinoPageTransitionsBuilder(),
      TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
      TargetPlatform.linux: CupertinoPageTransitionsBuilder(),
      TargetPlatform.fuchsia: CupertinoPageTransitionsBuilder(),
    }),
    actionIconTheme: ActionIconThemeData(
      backButtonIconBuilder: (_) => const Icon(Icons.arrow_back_ios_new_rounded, size: 21),
    ),
    textTheme: ThemeData(brightness: b).textTheme.apply(bodyColor: label, displayColor: label).copyWith(
          bodyLarge: TextStyle(fontSize: 17, letterSpacing: -0.4, color: label),
          bodyMedium: TextStyle(fontSize: 17, letterSpacing: -0.4, color: label),
          titleMedium: TextStyle(fontSize: 17, letterSpacing: -0.4, color: label),
          titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: 0.35, color: label),
          headlineSmall: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: 0.36, color: label),
        ),
    appBarTheme: AppBarTheme(
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      foregroundColor: blue,
      iconTheme: IconThemeData(color: blue),
      actionsIconTheme: IconThemeData(color: blue),
      titleTextStyle: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: -0.4, color: label),
    ),
    dividerTheme: DividerThemeData(color: sep, thickness: 0.5, space: 0.5),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: card,
      border: inputBorder,
      enabledBorder: inputBorder,
      focusedBorder: inputBorder,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      hintStyle: const TextStyle(color: kGray),
      labelStyle: const TextStyle(color: kGray),
      floatingLabelStyle: TextStyle(color: blue),
      prefixIconColor: kGray,
      suffixIconColor: kGray,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(50),
        backgroundColor: blue,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: -0.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: blue,
        textStyle: const TextStyle(fontSize: 17, letterSpacing: -0.4),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(style: IconButton.styleFrom(foregroundColor: blue)),
    listTileTheme: ListTileThemeData(iconColor: blue, textColor: label),
    bottomSheetTheme: const BottomSheetThemeData(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: d ? const Color(0xFF3A3A3C) : const Color(0xFF2C2C2E),
      contentTextStyle: const TextStyle(color: Colors.white, fontSize: 15, letterSpacing: -0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: blue),
  );
}

/// iOS kontakt avatari: kulrang gradient doira + oq bosh harf.
Widget avatar(String? url, String name, {double r = 24}) {
  final has = url != null && url.isNotEmpty;
  return Container(
    width: r * 2, height: r * 2,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: has
          ? null
          : const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFA5ABB8), Color(0xFF7F8590)]),
      image: has ? DecorationImage(image: NetworkImage(url!), fit: BoxFit.cover) : null,
    ),
    alignment: Alignment.center,
    child: has
        ? null
        : Text(name.isEmpty ? '?' : name[0].toUpperCase(),
            style: TextStyle(fontSize: r * 0.85, fontWeight: FontWeight.w500, color: Colors.white)),
  );
}
