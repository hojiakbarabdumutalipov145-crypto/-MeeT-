import 'package:flutter/material.dart';
import 'core.dart';
import 'glass.dart';
import 'l10n.dart';
import 'pages/call_page.dart';

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

Future<String?> ask(BuildContext c, String title, {bool obscure = false}) {
  final ctl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (d) => Dialog(
      backgroundColor: Colors.transparent, elevation: 0,
      child: Glass(
        radius: 14, blur: 30,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: -0.4)),
              const SizedBox(height: 14),
              TextField(
                controller: ctl, autofocus: true, obscureText: obscure,
                decoration: InputDecoration(
                  isDense: true,
                  fillColor: sysFill(d),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                ),
              ),
            ]),
          ),
          AlertButtons(
            left: t('cancel'), right: t('save'),
            onLeft: () => Navigator.pop(d),
            onRight: () => Navigator.pop(d, ctl.text.trim()),
          ),
        ]),
      ),
    ),
  );
}

Future<void> startCall(BuildContext c, String peerId, String peerName, String kind) async {
  try {
    final r = await sb.from('calls').insert({'caller_id': me, 'callee_id': peerId, 'kind': kind}).select().single();
    if (!c.mounted) return;
    Navigator.push(c, MaterialPageRoute(
        builder: (_) => CallPage(callId: r['id'], caller: true, video: kind == 'video', peer: peerName)));
  } catch (e) {
    if (c.mounted) snack(c, '$e');
  }
}
