import 'dart:ui';
import 'package:flutter/material.dart';
import 'core.dart';
import 'l10n.dart';

// =====================================================================
//  Apple Human Interface Guidelines uslubidagi umumiy dizayn vidjetlari.
//  (Fayl va klass nomlari oldingi versiya bilan bir xil — faqat koʻrinish.)
// =====================================================================

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

Color sysBlue(BuildContext c) => isDark(c) ? kBlueDark : kBlue;
Color sysBg(BuildContext c) => isDark(c) ? Colors.black : const Color(0xFFF2F2F7);
Color sysCard(BuildContext c) => isDark(c) ? const Color(0xFF1C1C1E) : Colors.white;
Color sysSep(BuildContext c) => isDark(c) ? const Color(0xFF38383A) : const Color(0xFFC6C6C8);
Color sysLabel2(BuildContext c) => isDark(c) ? const Color(0x99EBEBF5) : const Color(0x993C3C43);
Color sysFill(BuildContext c) => isDark(c) ? const Color(0x5C787880) : const Color(0x1F787880);
Color sysBar(BuildContext c) => isDark(c) ? const Color(0xE61C1C1E) : const Color(0xE6F9F9F9);

/// Butun ilova foni: systemGroupedBackground.
class Aurora extends StatelessWidget {
  final Widget child;
  const Aurora({super.key, required this.child});

  @override
  Widget build(BuildContext context) => ColoredBox(color: sysBg(context), child: child);
}

/// Panel: oddiy holatda toʻq qoplama (card), `blur > 0` boʻlsa yarim shaffof "material".
class Glass extends StatelessWidget {
  final Widget child;
  final double radius, blur;
  final EdgeInsetsGeometry? padding, margin;
  final Gradient? tint;
  const Glass({super.key, required this.child, this.radius = 14, this.blur = 18, this.padding, this.margin, this.tint});

  @override
  Widget build(BuildContext context) {
    final br = BorderRadius.circular(radius);
    final translucent = blur > 0;
    Widget panel = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: br,
        gradient: tint,
        color: tint != null ? null : (translucent ? sysBar(context) : sysCard(context)),
      ),
      child: child,
    );
    if (translucent) {
      panel = BackdropFilter(filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30), child: panel);
    }
    return Container(margin: margin, child: ClipRRect(borderRadius: br, child: panel));
  }
}

/// Navigatsiya paneli fon qatlami (yarim shaffof + ingichka ajratgich): AppBar(flexibleSpace: glassBar())
Widget glassBar() => const _GlassBar();

class _GlassBar extends StatelessWidget {
  const _GlassBar();
  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          decoration: BoxDecoration(
            color: sysBar(context),
            border: Border(bottom: BorderSide(color: sysSep(context), width: 0.5)),
          ),
        ),
      ),
    );
  }
}

class NavItem {
  final IconData icon, activeIcon;
  final String label;
  const NavItem(this.icon, this.activeIcon, this.label);
}

/// iOS Tab Bar: yarim shaffof fon, tepada ingichka chiziq, tanlangani systemBlue.
class BubbleNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  final List<NavItem> items;
  const BubbleNav({super.key, required this.index, required this.onTap, required this.items});

  @override
  Widget build(BuildContext context) {
    final blue = sysBlue(context);
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          decoration: BoxDecoration(
            color: sysBar(context),
            border: Border(top: BorderSide(color: sysSep(context), width: 0.5)),
          ),
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 49,
              child: Row(children: [
                for (var k = 0; k < items.length; k++)
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => onTap(k),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(k == index ? items[k].activeIcon : items[k].icon, size: 26, color: k == index ? blue : kGray),
                        const SizedBox(height: 2),
                        Text(items[k].label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 10, fontWeight: FontWeight.w500, letterSpacing: 0.1, color: k == index ? blue : kGray)),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------
//  Katta sarlavha (Large Title)
// ---------------------------------------------------------------------

class LargeTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const LargeTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(
            child: Text(text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700, letterSpacing: 0.37, height: 1.15)),
          ),
          if (trailing != null) trailing!,
        ]),
      );
}

// ---------------------------------------------------------------------
//  Inset Grouped List: Group (yumaloq blok) + Cell (qator)
// ---------------------------------------------------------------------

class Group extends StatelessWidget {
  final List<Widget> children;
  final String? header;
  final double indent;
  final EdgeInsetsGeometry margin;
  const Group({super.key, required this.children, this.header, this.indent = 16, this.margin = const EdgeInsets.fromLTRB(16, 0, 16, 28)});

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var k = 0; k < children.length; k++) {
      if (k > 0) rows.add(Divider(height: 0.5, thickness: 0.5, indent: indent, color: sysSep(context)));
      rows.add(children[k]);
    }
    return Padding(
      padding: margin,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (header != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 7),
            child: Text(header!.toUpperCase(), style: TextStyle(fontSize: 13, letterSpacing: -0.1, color: sysLabel2(context))),
          ),
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            color: sysCard(context),
            child: Material(color: Colors.transparent, child: Column(children: rows)),
          ),
        ),
      ]),
    );
  }
}

class Cell extends StatelessWidget {
  final Widget? leading;
  final String title;
  final Widget? subtitle;
  final String? value;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color? titleColor;
  final bool chevron, center;
  final double minHeight;
  const Cell({
    super.key,
    required this.title,
    this.leading,
    this.subtitle,
    this.value,
    this.trailing,
    this.onTap,
    this.titleColor,
    this.chevron = false,
    this.center = false,
    this.minHeight = 44,
  });

  @override
  Widget build(BuildContext context) {
    final titleW = Text(title,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        textAlign: center ? TextAlign.center : TextAlign.start,
        style: TextStyle(fontSize: 17, letterSpacing: -0.4, color: titleColor));
    final body = Row(children: [
      if (leading != null) ...[leading!, const SizedBox(width: 12)],
      if (center)
        Expanded(child: titleW)
      else if (value != null) ...[
        titleW,
        const SizedBox(width: 12),
        Expanded(
          child: Text(value!,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 17, letterSpacing: -0.4, color: sysLabel2(context))),
        ),
      ] else
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            titleW,
            if (subtitle != null)
              DefaultTextStyle(
                style: TextStyle(fontSize: 14, letterSpacing: -0.2, color: sysLabel2(context)),
                child: Padding(padding: const EdgeInsets.only(top: 2), child: subtitle!),
              ),
          ]),
        ),
      if (trailing != null) ...[const SizedBox(width: 8), trailing!],
      if (chevron) ...[
        const SizedBox(width: 4),
        Icon(Icons.chevron_right_rounded, size: 24, color: isDark(context) ? const Color(0x4DEBEBF5) : const Color(0x4D3C3C43)),
      ],
    ]);
    return InkWell(
      onTap: onTap,
      child: ConstrainedBox(
        constraints: BoxConstraints(minHeight: minHeight),
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: body),
      ),
    );
  }
}

/// iOS Settings uslubidagi rangli kvadrat ikonka.
class IconTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  const IconTile(this.icon, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 30, height: 30,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(7)),
        child: Icon(icon, size: 19, color: Colors.white),
      );
}

// ---------------------------------------------------------------------
//  Action Sheet va Alert (dialog) uslublari
// ---------------------------------------------------------------------

/// iOS Action Sheet: yumaloq yarim shaffof blok + alohida "Bekor qilish" tugmasi.
Widget actionSheet(BuildContext sheetCtx, List<Widget> rows) {
  return SafeArea(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Glass(
          radius: 14, blur: 30,
          child: Material(
            color: Colors.transparent,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (var k = 0; k < rows.length; k++) ...[
                if (k > 0) Divider(height: 0.5, thickness: 0.5, color: sysSep(sheetCtx)),
                rows[k],
              ],
            ]),
          ),
        ),
        const SizedBox(height: 8),
        Glass(
          radius: 14, blur: 0,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => Navigator.pop(sheetCtx),
              child: SizedBox(
                height: 56,
                child: Center(
                  child: Text(t('cancel'), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: sysBlue(sheetCtx))),
                ),
              ),
            ),
          ),
        ),
      ]),
    ),
  );
}

/// iOS Alert tugmalar qatori: yuqorida ingichka chiziq, orasida vertikal chiziq.
class AlertButtons extends StatelessWidget {
  final String left, right;
  final VoidCallback onLeft, onRight;
  final Color? leftColor;
  const AlertButtons({super.key, required this.left, required this.right, required this.onLeft, required this.onRight, this.leftColor});

  @override
  Widget build(BuildContext context) {
    final sep = sysSep(context);
    Widget btn(String s, VoidCallback f, Color c, FontWeight w) => Expanded(
          child: InkWell(
            onTap: f,
            child: SizedBox(height: 46, child: Center(child: Text(s, style: TextStyle(fontSize: 17, fontWeight: w, color: c)))),
          ),
        );
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Divider(height: 0.5, thickness: 0.5, color: sep),
      Material(
        color: Colors.transparent,
        child: IntrinsicHeight(
          child: Row(children: [
            btn(left, onLeft, leftColor ?? sysBlue(context), FontWeight.w400),
            VerticalDivider(width: 0.5, thickness: 0.5, color: sep),
            btn(right, onRight, sysBlue(context), FontWeight.w600),
          ]),
        ),
      ),
    ]);
  }
}
