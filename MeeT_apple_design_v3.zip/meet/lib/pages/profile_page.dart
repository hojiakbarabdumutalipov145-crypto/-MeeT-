import 'package:flutter/cupertino.dart' show CupertinoActivityIndicator;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<String, dynamic>? p;
  int chatsN = 0, callsN = 0, daysN = 0;
  final name = TextEditingController(), bio = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await sb.from('profiles').select().eq('id', me).single();
    name.text = r['name'] ?? '';
    bio.text = r['bio'] ?? '';
    try {
      chatsN = (await sb.from('chat_members').select('chat_id').eq('user_id', me)).length;
      callsN = (await sb.from('calls').select('id')).length;
      daysN = DateTime.now().difference(DateTime.parse(r['created_at'])).inDays;
    } catch (_) {}
    if (mounted) setState(() => p = r);
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 85);
    if (x == null) return;
    try {
      final bytes = await x.readAsBytes();
      await sb.storage.from('avatars').uploadBinary('$me.jpg', bytes,
          fileOptions: const FileOptions(upsert: true, contentType: 'image/jpeg'));
      final url = '${sb.storage.from('avatars').getPublicUrl('$me.jpg')}?t=${DateTime.now().millisecondsSinceEpoch}';
      await sb.from('profiles').update({'avatar_url': url}).eq('id', me);
      _load();
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _save() async {
    await sb.from('profiles').update({'name': name.text.trim(), 'bio': bio.text.trim()}).eq('id', me);
    if (mounted) snack(context, t('saved'));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: p == null
          ? Column(children: [LargeTitle(t('profile')), const Expanded(child: Center(child: CupertinoActivityIndicator()))])
          : ListView(padding: const EdgeInsets.only(bottom: 110), children: [
              LargeTitle(t('profile')),
              const SizedBox(height: 8),
              Center(
                child: Stack(children: [
                  avatar(p!['avatar_url'], p!['name'] ?? '', r: 58),
                  Positioned(
                    right: 0, bottom: 0,
                    child: GestureDetector(
                      onTap: _pick,
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(color: sysBlue(context), shape: BoxShape.circle, border: Border.all(color: sysBg(context), width: 3)),
                        child: const Icon(Icons.camera_alt_rounded, size: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Center(child: Text(p!['name'] ?? '', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: 0.36))),
              const SizedBox(height: 2),
              Center(child: Text('@${p!['username']}', style: TextStyle(color: sysLabel2(context), fontSize: 17))),
              const SizedBox(height: 24),
              StatsBlock(items: [('$chatsN', t('chats')), ('$callsN', t('calls')), ('$daysN', t('days'))]),
              Group(children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: name,
                    decoration: InputDecoration(hintText: t('name'), filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    controller: bio, maxLines: 3, minLines: 1,
                    decoration: InputDecoration(hintText: t('bio'), filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none),
                  ),
                ),
              ]),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: PillButton(t('save'), onTap: _save)),
            ]),
    );
  }
}
