import 'package:flutter/cupertino.dart' show CupertinoActivityIndicator;
import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';
import 'chat_page.dart';

class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  final _ctl = TextEditingController();
  List<Map<String, dynamic>>? data;
  Object? err;
  String q = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  // Qidiruv uchun: kichik harf, @ va apostrof turlari (' ʻ ʼ ‘ ’ ` ´) olib tashlanadi
  static String _norm(String s) =>
      s.toLowerCase().replaceAll(RegExp("[\u02BB\u02BC\u2018\u2019`\u00B4'@]"), '').trim();

  Future<void> _refresh() async {
    try {
      final d = await _load();
      if (!mounted) return;
      setState(() { data = d; err = null; });
    } catch (e) {
      if (!mounted) return;
      setState(() => err = e);
    }
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await sb.from('chat_members').select('chats(id,type,title,created_by)').eq('user_id', me);
    final out = <Map<String, dynamic>>[];
    for (final r in rows) {
      final c = Map<String, dynamic>.from(r['chats'] as Map);
      if (c['type'] == 'direct') {
        final o = await sb.from('chat_members').select('user_id,profiles(name,username,avatar_url)')
            .eq('chat_id', c['id']).neq('user_id', me).maybeSingle();
        final pr = o?['profiles'] as Map?;
        c['title'] = pr?['name'] ?? pr?['username'] ?? '?';
        c['username'] = pr?['username'] ?? '';
        c['avatar'] = pr?['avatar_url'];
        c['peer'] = o?['user_id'];
      }
      out.add(c);
    }
    return out;
  }

  void _reload() => _refresh();

  Future<void> _newDirect() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    if (p['id'] == me) return;
    try {
      await sb.rpc('create_direct_chat', params: {'other': p['id']});
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    _reload();
  }

  Future<void> _newGroup(String type) async {
    final title = await ask(context, t('title'));
    if (title == null || title.isEmpty) return;
    final c = await sb.from('chats').insert({'type': type, 'title': title, 'created_by': me}).select().single();
    await sb.from('chat_members').insert({'chat_id': c['id'], 'user_id': me});
    _reload();
  }

  void _sheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (d) => actionSheet(d, [
        Cell(leading: Icon(Icons.person_add_alt_1_outlined, color: sysBlue(d)), title: t('newDirect'), minHeight: 56, onTap: () { Navigator.pop(d); _newDirect(); }),
        Cell(leading: Icon(Icons.group_add_outlined, color: sysBlue(d)), title: t('newGroup'), minHeight: 56, onTap: () { Navigator.pop(d); _newGroup('group'); }),
        Cell(leading: Icon(Icons.campaign_outlined, color: sysBlue(d)), title: t('newChannel'), minHeight: 56, onTap: () { Navigator.pop(d); _newGroup('channel'); }),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final head = [
      AppHeader(actionIcon: Icons.edit_rounded, onAction: _sheet),
      LargeTitle(t('chats')),
      SearchField(
        controller: _ctl,
        hint: t('search'),
        onChanged: (v) => setState(() => q = _norm(v)),
      ),
    ];
    final all = data;
    final List<Map<String, dynamic>> list = (all == null)
        ? const []
        : (q.isEmpty
            ? all
            : all.where((c) => _norm('${c['title'] ?? ''}').contains(q) || _norm('${c['username'] ?? ''}').contains(q)).toList());

    Widget body;
    if (all == null && err == null) {
      body = const SizedBox(height: 240, child: Center(child: CupertinoActivityIndicator()));
    } else if (all == null) {
      body = Padding(padding: const EdgeInsets.all(20), child: Center(child: Text('$err')));
    } else if (list.isEmpty) {
      body = SizedBox(
        height: 240,
        child: Center(child: Text(q.isEmpty ? t('noChats') : t('noResults'), style: TextStyle(color: sysLabel2(context)))),
      );
    } else {
      body = Group(
        indent: 76,
        children: [
          for (final c in list)
            Cell(
              key: ValueKey(c['id']),
              minHeight: 64,
              leading: c['type'] == 'channel' || c['type'] == 'group'
                  ? Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: c['type'] == 'channel' ? const [Color(0xFFFFB340), kOrange] : const [Color(0xFF5BD778), kGreen]),
                      ),
                      child: Icon(c['type'] == 'channel' ? Icons.campaign_rounded : Icons.group_rounded, color: Colors.white, size: 26),
                    )
                  : avatar(c['avatar'], c['title'] ?? ''),
              title: c['title'] ?? '',
              chevron: true,
              onTap: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chat: c)));
                _reload();
              },
            ),
        ],
      );
    }

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.only(bottom: 110),
          children: [
            ...head,
            if (q.isEmpty && all != null)
              PromoBanner(
                icon: Icons.group_add_rounded,
                title: t('bannerTitle'),
                subtitle: t('bannerSub'),
                onTap: () => _newGroup('group'),
              ),
            body,
          ],
        ),
      ),
    );
  }
}
