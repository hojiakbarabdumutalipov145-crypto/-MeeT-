import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../core.dart';
import '../l10n.dart';

class CallPage extends StatefulWidget {
  final String callId, peer;
  final bool caller, video;
  const CallPage({super.key, required this.callId, required this.caller, required this.video, required this.peer});
  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  final localR = RTCVideoRenderer(), remoteR = RTCVideoRenderer();
  RTCPeerConnection? pc;
  MediaStream? local;
  RealtimeChannel? ch, rowCh;
  Timer? readyTimer, ringTimer;
  Map<String, dynamic>? offerMsg;
  bool muted = false, camOff = false, connected = false, closed = false;
  bool remoteSet = false, gotOffer = false, offering = false;
  final pending = <RTCIceCandidate>[];
  String status = '';

  @override
  void initState() {
    super.initState();
    status = widget.caller ? t('calling') : '…';
    _start();
  }

  void _send(Map<String, dynamic> m) => ch?.sendBroadcastMessage(payload: m, event: 'sig');

  Future<void> _start() async {
    await localR.initialize();
    await remoteR.initialize();
    try {
      local = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': widget.video ? {'facingMode': 'user'} : false,
      });
    } catch (e) {
      if (mounted) setState(() => status = '$e');
      return;
    }
    if (closed) return;
    localR.srcObject = local;
    try { await Helper.setSpeakerphoneOn(widget.video); } catch (_) {}
    pc = await createPeerConnection(kIceConfig);
    for (final tr in local!.getTracks()) {
      await pc!.addTrack(tr, local!);
    }
    pc!.onTrack = (e) {
      if (e.streams.isNotEmpty) {
        remoteR.srcObject = e.streams[0];
        if (mounted) setState(() {});
      }
    };
    pc!.onIceCandidate = (c) => _send({'t': 'ice', 'c': c.toMap()});
    pc!.onConnectionState = (s) {
      if (!mounted) return;
      setState(() {
        connected = s == RTCPeerConnectionState.RTCPeerConnectionStateConnected;
        if (connected) status = '';
      });
      if (connected) ringTimer?.cancel();
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) _end();
    };

    // Qoʻngʻiroq holati (rad etildi / bekor qilindi) ni kuzatish
    rowCh = sb
        .channel('callrow_${widget.callId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: widget.callId),
          callback: (pl) {
            final s = pl.newRecord['status'];
            if (connected) return;
            if (widget.caller && s == 'declined') _end(remote: true);
            if (!widget.caller && s == 'missed') _end(remote: true);
          },
        )
        .subscribe();

    ch = sb.channel('call_${widget.callId}');
    ch!.onBroadcast(
      event: 'sig',
      callback: (p) => _onSig(Map<String, dynamic>.from((p['payload'] ?? p) as Map)),
    );
    ch!.subscribe((s, [e]) {
      if (s == RealtimeSubscribeStatus.subscribed && !widget.caller) {
        // 'ready' yoʻqolib qolmasligi uchun offer kelguncha qayta-qayta yuboriladi
        _send({'t': 'ready'});
        readyTimer = Timer.periodic(const Duration(milliseconds: 1500), (_) {
          if (gotOffer || closed) {
            readyTimer?.cancel();
          } else {
            _send({'t': 'ready'});
          }
        });
      }
    });

    // Ulanmasa 40 soniyadan keyin tugatish
    ringTimer = Timer(const Duration(seconds: 40), () {
      if (!connected) _end();
    });
  }

  Future<void> _flush() async {
    for (final c in pending) { await pc!.addCandidate(c); }
    pending.clear();
  }

  Future<void> _onSig(Map<String, dynamic> d) async {
    final p = pc;
    if (p == null || closed) return;
    switch (d['t']) {
      case 'ready':
        if (!widget.caller) break;
        if (offerMsg == null) {
          if (offering) break;
          offering = true;
          final o = await p.createOffer();
          await p.setLocalDescription(o);
          offerMsg = {'t': 'offer', 'sdp': o.sdp, 'type': o.type};
        }
        _send(offerMsg!);
        break;
      case 'offer':
        if (gotOffer) break;
        gotOffer = true;
        readyTimer?.cancel();
        await p.setRemoteDescription(RTCSessionDescription(d['sdp'], d['type']));
        remoteSet = true;
        await _flush();
        final a = await p.createAnswer();
        await p.setLocalDescription(a);
        _send({'t': 'answer', 'sdp': a.sdp, 'type': a.type});
        break;
      case 'answer':
        if (remoteSet) break;
        await p.setRemoteDescription(RTCSessionDescription(d['sdp'], d['type']));
        remoteSet = true;
        await _flush();
        break;
      case 'ice':
        final c = Map<String, dynamic>.from(d['c'] as Map);
        final ic = RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex']);
        if (remoteSet) { await p.addCandidate(ic); } else { pending.add(ic); }
        break;
      case 'end':
        _end(remote: true);
        break;
    }
  }

  Future<void> _end({bool remote = false}) async {
    if (closed) return;
    closed = true;
    readyTimer?.cancel();
    ringTimer?.cancel();
    if (!remote) _send({'t': 'end'});
    if (widget.caller && !connected) {
      try { await sb.from('calls').update({'status': 'missed'}).eq('id', widget.callId).eq('status', 'ringing'); } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    readyTimer?.cancel();
    ringTimer?.cancel();
    for (final tr in local?.getTracks() ?? <MediaStreamTrack>[]) { tr.stop(); }
    local?.dispose();
    pc?.close();
    localR.dispose();
    remoteR.dispose();
    if (ch != null) sb.removeChannel(ch!);
    if (rowCh != null) sb.removeChannel(rowCh!);
    super.dispose();
  }

  Widget _btn(IconData i, VoidCallback f, {Color? bg}) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: CircleAvatar(radius: 30, backgroundColor: bg ?? Colors.white24, child: IconButton(icon: Icon(i, color: Colors.white), onPressed: f)),
      );

  @override
  Widget build(BuildContext context) {
    final showRemote = widget.video && remoteR.srcObject != null;
    return Scaffold(
      backgroundColor: kNavy,
      body: Stack(children: [
        if (showRemote) Positioned.fill(child: RTCVideoView(remoteR, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover))
        else Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            avatar(null, widget.peer, r: 60),
            const SizedBox(height: 20),
            Text(widget.peer, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(status, style: const TextStyle(color: Colors.white70)),
          ]),
        ),
        if (widget.video && local != null)
          Positioned(
            top: 50, right: 16, width: 110, height: 160,
            child: ClipRRect(borderRadius: BorderRadius.circular(16), child: RTCVideoView(localR, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)),
          ),
        Positioned(
          bottom: 40, left: 0, right: 0,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _btn(muted ? Icons.mic_off : Icons.mic, () {
              setState(() => muted = !muted);
              for (final tr in local?.getAudioTracks() ?? <MediaStreamTrack>[]) { tr.enabled = !muted; }
            }),
            if (widget.video)
              _btn(camOff ? Icons.videocam_off : Icons.videocam, () {
                setState(() => camOff = !camOff);
                for (final tr in local?.getVideoTracks() ?? <MediaStreamTrack>[]) { tr.enabled = !camOff; }
              }),
            _btn(Icons.call_end, _end, bg: Colors.red),
          ]),
        ),
      ]),
    );
  }
}
