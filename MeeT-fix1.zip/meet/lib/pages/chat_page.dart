import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';

class ChatPage extends StatefulWidget {
  final Map<String, dynamic> chat;
  const ChatPage({super.key, required this.chat});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctl = TextEditingController();
  late final Stream<List<Map<String, dynamic>>> stream = sb
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('chat_id', widget.chat['id'])
      .order('created_at', ascending: false)
      .limit(200);

  bool get direct => widget.chat['type'] == 'direct';
  bool get readOnly => widget.chat['type'] == 'channel' && widget.chat['created_by'] != me;

  Future<void> _send() async {
    final text = ctl.text.trim();
    if (text.isEmpty) return;
    ctl.clear();
    try {
      await sb.from('messages').insert({'chat_id': widget.chat['id'], 'sender_id': me, 'type': 'text', 'content': text});
    } catch (e) {
      if (mounted) {
        ctl.text = text;
        ctl.selection = TextSelection.collapsed(offset: text.length);
        snack(context, '$e');
      }
    }
  }

  Future<void> _addMember() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    try {
      await sb.from('chat_members').insert({'chat_id': widget.chat['id'], 'user_id': p['id']});
      if (mounted) snack(context, t('saved'));
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.chat['title'] ?? '';
    final peer = widget.chat['peer'] as String?;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          if (direct && peer != null) ...[
            IconButton(icon: const Icon(Icons.call), onPressed: () => startCall(context, peer, title, 'audio')),
            IconButton(icon: const Icon(Icons.videocam), onPressed: () => startCall(context, peer, title, 'video')),
          ] else if (!direct && widget.chat['created_by'] == me)
            IconButton(icon: const Icon(Icons.person_add), tooltip: t('addMember'), onPressed: _addMember),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: stream,
            builder: (context, s) {
              if (s.hasError) return Center(child: Text('${s.error}'));
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final msgs = s.data!;
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: msgs.length,
                itemBuilder: (_, k) {
                  final m = msgs[k];
                  final mine = m['sender_id'] == me;
                  final time = DateTime.parse(m['created_at']).toLocal();
                  final hh = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
                  return Align(
                    alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 3),
                      padding: const EdgeInsets.fromLTRB(14, 9, 12, 7),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                      decoration: BoxDecoration(
                        gradient: mine ? const LinearGradient(colors: [kBlue, Color(0xFF3D8BFF)]) : null,
                        color: mine ? null : Theme.of(context).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
                          bottomLeft: Radius.circular(mine ? 18 : 4), bottomRight: Radius.circular(mine ? 4 : 18),
                        ),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                        Text(m['content'] ?? '', style: TextStyle(fontSize: 16, color: mine ? Colors.white : null)),
                        const SizedBox(height: 2),
                        Text(hh, style: TextStyle(fontSize: 11, color: mine ? Colors.white70 : Colors.grey)),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          top: false,
          child: readOnly
              ? Padding(padding: const EdgeInsets.all(16), child: Text(t('channelReadonly'), style: const TextStyle(color: Colors.grey)))
              : Padding(
                  padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: ctl,
                        minLines: 1, maxLines: 5,
                        onSubmitted: (_) => _send(),
                        decoration: InputDecoration(hintText: t('message'), contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    CircleAvatar(radius: 24, backgroundColor: kBlue, child: IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: _send)),
                  ]),
                ),
        ),
      ]),
    );
  }
}
