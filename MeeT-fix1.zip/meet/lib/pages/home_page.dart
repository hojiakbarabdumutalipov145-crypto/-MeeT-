import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import 'call_page.dart';
import 'calls_page.dart';
import 'chats_page.dart';
import 'profile_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int i = 0;
  RealtimeChannel? ch;
  String? ringingId;
  BuildContext? dlg;
  bool inCall = false;

  @override
  void initState() {
    super.initState();
    ch = sb
        .channel('incoming_$me')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: me),
          callback: (pl) => _incoming(pl.newRecord),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: me),
          callback: (pl) {
            // Chaquvchi bekor qilsa, kiruvchi qoʻngʻiroq oynasi yopiladi
            final r = pl.newRecord;
            final d = dlg;
            if (r['id'] == ringingId && r['status'] != 'ringing' && d != null && d.mounted) {
              Navigator.pop(d, null);
            }
          },
        )
        .subscribe();
  }

  @override
  void dispose() {
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Future<void> _incoming(Map<String, dynamic> c) async {
    final id = c['id'] as String;
    // Eski yoki band boʻlgan holatda avtomatik rad etiladi
    final age = DateTime.now().toUtc().difference(DateTime.parse(c['created_at']).toUtc());
    if (age.inSeconds > 60) return;
    if (ringingId != null || inCall) {
      await sb.from('calls').update({'status': 'declined'}).eq('id', id).eq('status', 'ringing');
      return;
    }
    final who = await sb.from('profiles').select('name').eq('id', c['caller_id']).single();
    if (!mounted) return;
    ringingId = id;
    final ok = await showDialog<bool?>(
      context: context,
      barrierDismissible: false,
      builder: (d) {
        dlg = d;
        return AlertDialog(
          title: Text('${t('incoming')} ${c['kind'] == 'video' ? t('video') : t('audio')}'),
          content: Text(who['name'] ?? '', style: const TextStyle(fontSize: 20)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: Text(t('decline'), style: const TextStyle(color: Colors.red))),
            FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(110, 44)), onPressed: () => Navigator.pop(d, true), child: Text(t('accept'))),
          ],
        );
      },
    );
    ringingId = null;
    dlg = null;
    if (ok == true) {
      final res = await sb.from('calls').update({'status': 'answered'}).eq('id', id).eq('status', 'ringing').select();
      if (!mounted) return;
      if (res.isEmpty) {
        snack(context, t('callEnded'));
        return;
      }
      inCall = true;
      await Navigator.push(context, MaterialPageRoute(
          builder: (_) => CallPage(callId: id, caller: false, video: c['kind'] == 'video', peer: who['name'] ?? '')));
      inCall = false;
    } else if (ok == false) {
      await sb.from('calls').update({'status': 'declined'}).eq('id', id).eq('status', 'ringing');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [const ChatsPage(), const CallsPage(), const SettingsPage(), const ProfilePage()];
    return Scaffold(
      body: IndexedStack(index: i, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => i = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.chat_bubble_outline), selectedIcon: const Icon(Icons.chat_bubble), label: t('chats')),
          NavigationDestination(icon: const Icon(Icons.call_outlined), selectedIcon: const Icon(Icons.call), label: t('calls')),
          NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings), label: t('settings')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: t('profile')),
        ],
      ),
    );
  }
}
