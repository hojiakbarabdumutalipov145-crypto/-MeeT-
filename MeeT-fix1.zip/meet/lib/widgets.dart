import 'package:flutter/material.dart';
import 'core.dart';
import 'l10n.dart';
import 'pages/call_page.dart';

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

Future<String?> ask(BuildContext c, String title, {bool obscure = false}) {
  final ctl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: TextField(controller: ctl, autofocus: true, obscureText: obscure),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: Text(t('cancel'))),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(90, 44)),
          onPressed: () => Navigator.pop(d, ctl.text.trim()),
          child: Text(t('save')),
        ),
      ],
    ),
  );
}

Future<void> startCall(BuildContext c, String peerId, String peerName, String kind) async {
  try {
    final r = await sb.from('calls').insert({'caller_id': me, 'callee_id': peerId, 'kind': kind}).select().single();
    if (!c.mounted) return;
    Navigator.push(c, MaterialPageRoute(
        builder: (_) => CallPage(callId: r['id'], caller: true, video: kind == 'video', peer: peerName)));
  } catch (e) {
    if (c.mounted) snack(c, '$e');
  }
}
