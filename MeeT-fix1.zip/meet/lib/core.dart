import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);
final appLocale = ValueNotifier<String>('uz');
SupabaseClient get sb => Supabase.instance.client;
String get me => sb.auth.currentUser!.id;

const kBlue = Color(0xFF1E6BFF);
const kNavy = Color(0xFF020B3D);
const kCyan = Color(0xFF22D3EE);

ThemeData buildTheme(Brightness b) {
  final cs = ColorScheme.fromSeed(seedColor: kBlue, brightness: b);
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    scaffoldBackgroundColor: b == Brightness.dark ? const Color(0xFF060B24) : const Color(0xFFF4F7FF),
    appBarTheme: const AppBarTheme(centerTitle: false, scrolledUnderElevation: 0, backgroundColor: Colors.transparent),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      height: 68,
      indicatorColor: kBlue.withOpacity(0.18),
    ),
  );
}

Widget avatar(String? url, String name, {double r = 24}) => CircleAvatar(
      radius: r,
      backgroundColor: kBlue.withOpacity(0.2),
      backgroundImage: (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
      child: (url == null || url.isEmpty)
          ? Text(name.isEmpty ? '?' : name[0].toUpperCase(),
              style: TextStyle(fontSize: r * 0.8, fontWeight: FontWeight.w700, color: kBlue))
          : null,
    );
