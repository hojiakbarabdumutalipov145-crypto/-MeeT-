import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);
final appLocale = ValueNotifier<String>('uz');
final tabIndex = ValueNotifier<int>(0);
SupabaseClient get sb => Supabase.instance.client;
String get me => sb.auth.currentUser!.id;

// iOS system colors
const kBlue = Color(0xFF007AFF);
const kGreen = Color(0xFF34C759);
const kRed = Color(0xFFFF3B30);
const kOrange = Color(0xFFFF9500);
const kIndigo = Color(0xFF5856D6);
const kGray = Color(0xFF8E8E93);
const kNavy = Color(0xFF020B3D);
const kCyan = Color(0xFF22D3EE);

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
Color bgOf(BuildContext c) => isDark(c) ? Colors.black : const Color(0xFFF2F2F7);
Color cardOf(BuildContext c) => isDark(c) ? const Color(0xFF1C1C1E) : Colors.white;
Color lineOf(BuildContext c) => isDark(c) ? const Color(0xFF38383A) : const Color(0xFFE5E5EA);
Color fillOf(BuildContext c) => isDark(c) ? const Color(0x3D767680) : const Color(0x1F767680);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final cs = ColorScheme.fromSeed(seedColor: kBlue, brightness: b).copyWith(primary: kBlue, onPrimary: Colors.white);
  final bg = dark ? Colors.black : const Color(0xFFF2F2F7);
  final fg = dark ? Colors.white : Colors.black;
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    scaffoldBackgroundColor: bg,
    splashFactory: NoSplash.splashFactory,
    highlightColor: dark ? const Color(0x1FFFFFFF) : const Color(0x0F000000),
    pageTransitionsTheme: PageTransitionsTheme(builders: {
      for (final p in TargetPlatform.values) p: const CupertinoPageTransitionsBuilder(),
    }),
    appBarTheme: AppBarTheme(
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 0,
      backgroundColor: bg,
      foregroundColor: fg,
      surfaceTintColor: Colors.transparent,
      titleTextStyle: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: fg),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? const Color(0x3D767680) : const Color(0x1F767680),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: const StadiumBorder(),
        backgroundColor: kBlue,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    ),
  );
}

Widget avatar(String? url, String name, {double r = 24}) => CircleAvatar(
      radius: r,
      backgroundColor: kBlue.withOpacity(0.15),
      backgroundImage: (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
      child: (url == null || url.isEmpty)
          ? Text(name.isEmpty ? '?' : name[0].toUpperCase(),
              style: TextStyle(fontSize: r * 0.8, fontWeight: FontWeight.w600, color: kBlue))
          : null,
    );
