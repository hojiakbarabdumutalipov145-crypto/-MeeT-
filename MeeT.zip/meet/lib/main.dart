import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'core.dart';
import 'pages/auth_page.dart';
import 'pages/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseAnonKey);
  final p = await SharedPreferences.getInstance();
  appLocale.value = p.getString('lang') ?? 'uz';
  themeMode.value = ThemeMode.values[p.getInt('theme') ?? 0];
  runApp(const MeetApp());
}

class MeetApp extends StatelessWidget {
  const MeetApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: appLocale,
        builder: (_, lang, __) => ValueListenableBuilder<ThemeMode>(
          valueListenable: themeMode,
          builder: (_, mode, __) => MaterialApp(
            key: ValueKey(lang),
            title: 'MeeT',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(Brightness.light),
            darkTheme: buildTheme(Brightness.dark),
            themeMode: mode,
            home: const Gate(),
          ),
        ),
      );
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: sb.auth.onAuthStateChange,
        builder: (context, snap) => sb.auth.currentSession == null ? const AuthPage() : const HomePage(),
      );
}
