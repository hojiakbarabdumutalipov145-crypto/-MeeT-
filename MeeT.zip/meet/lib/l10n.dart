import 'core.dart';

const langNames = {'uz': 'Oʻzbekcha', 'ru': 'Русский', 'en': 'English'};

const _s = <String, Map<String, String>>{
  'en': {
    'signin': 'Sign in', 'signup': 'Create account', 'username': 'Username', 'password': 'Password',
    'name': 'Name', 'bio': 'About', 'chats': 'Chats', 'calls': 'Calls', 'settings': 'Settings',
    'profile': 'Profile', 'account': 'Account', 'privacy': 'Privacy & security', 'appearance': 'Appearance',
    'theme': 'Theme', 'light': 'Light', 'dark': 'Dark', 'system': 'System', 'language': 'Language',
    'logout': 'Log out', 'message': 'Message', 'newDirect': 'New chat', 'newGroup': 'New group',
    'newChannel': 'New channel', 'title': 'Title', 'create': 'Create', 'noChats': 'No chats yet',
    'noCalls': 'No calls yet', 'save': 'Save', 'cancel': 'Cancel', 'incoming': 'Incoming', 'audio': 'audio call',
    'video': 'video call', 'accept': 'Accept', 'decline': 'Decline', 'missed': 'Missed', 'addMember': 'Add member',
    'newUsername': 'New username', 'newPassword': 'New password', 'haveAcc': 'I already have an account',
    'noAcc': 'Create new account', 'notFound': 'User not found', 'channelReadonly': 'Only the owner can post',
    'calling': 'Calling…', 'saved': 'Saved', 'badUsername': 'Username: 3-20 chars, a-z, 0-9, _',
    'badPassword': 'Password must be at least 6 characters', 'userId': 'User ID', 'joined': 'Joined',
  },
  'ru': {
    'signin': 'Войти', 'signup': 'Создать аккаунт', 'username': 'Имя пользователя', 'password': 'Пароль',
    'name': 'Имя', 'bio': 'О себе', 'chats': 'Чаты', 'calls': 'Звонки', 'settings': 'Настройки',
    'profile': 'Профиль', 'account': 'Аккаунт', 'privacy': 'Конфиденциальность и безопасность', 'appearance': 'Оформление',
    'theme': 'Тема', 'light': 'Светлая', 'dark': 'Тёмная', 'system': 'Системная', 'language': 'Язык',
    'logout': 'Выйти', 'message': 'Сообщение', 'newDirect': 'Новый чат', 'newGroup': 'Новая группа',
    'newChannel': 'Новый канал', 'title': 'Название', 'create': 'Создать', 'noChats': 'Чатов пока нет',
    'noCalls': 'Звонков пока нет', 'save': 'Сохранить', 'cancel': 'Отмена', 'incoming': 'Входящий', 'audio': 'аудиозвонок',
    'video': 'видеозвонок', 'accept': 'Принять', 'decline': 'Отклонить', 'missed': 'Пропущенный', 'addMember': 'Добавить участника',
    'newUsername': 'Новое имя пользователя', 'newPassword': 'Новый пароль', 'haveAcc': 'У меня уже есть аккаунт',
    'noAcc': 'Создать новый аккаунт', 'notFound': 'Пользователь не найден', 'channelReadonly': 'Писать может только владелец',
    'calling': 'Вызов…', 'saved': 'Сохранено', 'badUsername': 'Имя: 3-20 символов, a-z, 0-9, _',
    'badPassword': 'Пароль не короче 6 символов', 'userId': 'ID пользователя', 'joined': 'Дата регистрации',
  },
  'uz': {
    'signin': 'Kirish', 'signup': 'Akkaunt yaratish', 'username': 'Foydalanuvchi nomi', 'password': 'Parol',
    'name': 'Ism', 'bio': 'Oʻzim haqimda', 'chats': 'Chatlar', 'calls': 'Qoʻngʻiroqlar', 'settings': 'Sozlamalar',
    'profile': 'Profil', 'account': 'Hisob', 'privacy': 'Maxfiylik va xavfsizlik', 'appearance': 'Koʻrinish',
    'theme': 'Mavzu', 'light': 'Yorugʻ', 'dark': 'Qorongʻu', 'system': 'Tizim', 'language': 'Til',
    'logout': 'Chiqish', 'message': 'Xabar', 'newDirect': 'Yangi chat', 'newGroup': 'Yangi guruh',
    'newChannel': 'Yangi kanal', 'title': 'Nomi', 'create': 'Yaratish', 'noChats': 'Hozircha chat yoʻq',
    'noCalls': 'Hozircha qoʻngʻiroq yoʻq', 'save': 'Saqlash', 'cancel': 'Bekor qilish', 'incoming': 'Kiruvchi', 'audio': 'audio qoʻngʻiroq',
    'video': 'video qoʻngʻiroq', 'accept': 'Qabul qilish', 'decline': 'Rad etish', 'missed': 'Oʻtkazib yuborilgan', 'addMember': 'Aʼzo qoʻshish',
    'newUsername': 'Yangi foydalanuvchi nomi', 'newPassword': 'Yangi parol', 'haveAcc': 'Akkauntim bor',
    'noAcc': 'Yangi akkaunt ochish', 'notFound': 'Foydalanuvchi topilmadi', 'channelReadonly': 'Faqat egasi yozishi mumkin',
    'calling': 'Qoʻngʻiroq qilinmoqda…', 'saved': 'Saqlandi', 'badUsername': 'Nom: 3-20 belgi, a-z, 0-9, _',
    'badPassword': 'Parol kamida 6 belgi boʻlsin', 'userId': 'Foydalanuvchi ID', 'joined': 'Roʻyxatdan oʻtgan sana',
  },
};

String t(String k) => _s[appLocale.value]?[k] ?? _s['en']![k] ?? k;
