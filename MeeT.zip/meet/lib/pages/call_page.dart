import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../core.dart';
import '../l10n.dart';

class CallPage extends StatefulWidget {
  final String callId, peer;
  final bool caller, video;
  const CallPage({super.key, required this.callId, required this.caller, required this.video, required this.peer});
  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  final localR = RTCVideoRenderer(), remoteR = RTCVideoRenderer();
  RTCPeerConnection? pc;
  MediaStream? local;
  RealtimeChannel? ch;
  bool muted = false, camOff = false, connected = false, closed = false, remoteSet = false;
  final pending = <RTCIceCandidate>[];
  String status = '';

  @override
  void initState() {
    super.initState();
    status = widget.caller ? t('calling') : '…';
    _start();
  }

  void _send(Map<String, dynamic> m) => ch?.sendBroadcastMessage(payload: m, event: 'sig');

  Future<void> _start() async {
    await localR.initialize();
    await remoteR.initialize();
    try {
      local = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': widget.video ? {'facingMode': 'user'} : false,
      });
    } catch (e) {
      if (mounted) setState(() => status = '$e');
      return;
    }
    localR.srcObject = local;
    try { await Helper.setSpeakerphoneOn(widget.video); } catch (_) {}
    pc = await createPeerConnection(kIceConfig);
    for (final tr in local!.getTracks()) {
      await pc!.addTrack(tr, local!);
    }
    pc!.onTrack = (e) {
      if (e.streams.isNotEmpty) {
        remoteR.srcObject = e.streams[0];
        if (mounted) setState(() {});
      }
    };
    pc!.onIceCandidate = (c) => _send({'t': 'ice', 'c': c.toMap()});
    pc!.onConnectionState = (s) {
      if (!mounted) return;
      setState(() {
        connected = s == RTCPeerConnectionState.RTCPeerConnectionStateConnected;
        if (connected) status = '';
      });
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) _end();
    };
    ch = sb.channel('call_${widget.callId}');
    ch!.onBroadcast(
      event: 'sig',
      callback: (p) => _onSig(Map<String, dynamic>.from((p['payload'] ?? p) as Map)),
    );
    ch!.subscribe((s, [e]) {
      if (s == RealtimeSubscribeStatus.subscribed && !widget.caller) _send({'t': 'ready'});
    });
  }

  Future<void> _flush() async {
    for (final c in pending) { await pc!.addCandidate(c); }
    pending.clear();
  }

  Future<void> _onSig(Map<String, dynamic> d) async {
    final p = pc;
    if (p == null) return;
    switch (d['t']) {
      case 'ready':
        final o = await p.createOffer();
        await p.setLocalDescription(o);
        _send({'t': 'offer', 'sdp': o.sdp, 'type': o.type});
        break;
      case 'offer':
        await p.setRemoteDescription(RTCSessionDescription(d['sdp'], d['type']));
        remoteSet = true;
        await _flush();
        final a = await p.createAnswer();
        await p.setLocalDescription(a);
        _send({'t': 'answer', 'sdp': a.sdp, 'type': a.type});
        break;
      case 'answer':
        await p.setRemoteDescription(RTCSessionDescription(d['sdp'], d['type']));
        remoteSet = true;
        await _flush();
        break;
      case 'ice':
        final c = Map<String, dynamic>.from(d['c'] as Map);
        final ic = RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex']);
        if (remoteSet) { await p.addCandidate(ic); } else { pending.add(ic); }
        break;
      case 'end':
        _end(remote: true);
        break;
    }
  }

  Future<void> _end({bool remote = false}) async {
    if (closed) return;
    closed = true;
    if (!remote) _send({'t': 'end'});
    if (widget.caller && !connected) {
      try { await sb.from('calls').update({'status': 'missed'}).eq('id', widget.callId).eq('status', 'ringing'); } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    for (final tr in local?.getTracks() ?? <MediaStreamTrack>[]) { tr.stop(); }
    local?.dispose();
    pc?.close();
    localR.dispose();
    remoteR.dispose();
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Widget _btn(IconData i, VoidCallback f, {Color? bg}) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: GestureDetector(
          onTap: f,
          child: Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(color: bg ?? Colors.white.withOpacity(0.18), shape: BoxShape.circle),
            child: Icon(i, color: Colors.white, size: 30),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final showRemote = widget.video && remoteR.srcObject != null;
    return Scaffold(
      backgroundColor: kNavy,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [kNavy, Color(0xFF0A2A9C)]),
        ),
        child: Stack(children: [
          if (showRemote) Positioned.fill(child: RTCVideoView(remoteR, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover))
          else Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              avatar(null, widget.peer, r: 64),
              const SizedBox(height: 24),
              Text(widget.peer, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(status, style: const TextStyle(color: Colors.white70, fontSize: 17)),
            ]),
          ),
          if (widget.video && local != null)
            Positioned(
              top: 56, right: 16, width: 110, height: 160,
              child: ClipRRect(borderRadius: BorderRadius.circular(18), child: RTCVideoView(localR, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)),
            ),
          Positioned(
            bottom: 48, left: 0, right: 0,
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _btn(muted ? Icons.mic_off_rounded : Icons.mic_rounded, () {
                setState(() => muted = !muted);
                for (final tr in local?.getAudioTracks() ?? <MediaStreamTrack>[]) { tr.enabled = !muted; }
              }),
              if (widget.video)
                _btn(camOff ? Icons.videocam_off_rounded : Icons.videocam_rounded, () {
                  setState(() => camOff = !camOff);
                  for (final tr in local?.getVideoTracks() ?? <MediaStreamTrack>[]) { tr.enabled = !camOff; }
                }),
              _btn(Icons.call_end_rounded, _end, bg: kRed),
            ]),
          ),
        ]),
      ),
    );
  }
}
