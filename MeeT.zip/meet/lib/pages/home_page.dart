import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';
import 'call_page.dart';
import 'calls_page.dart';
import 'chats_page.dart';
import 'profile_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int i = tabIndex.value;
  RealtimeChannel? ch;

  @override
  void initState() {
    super.initState();
    ch = sb
        .channel('incoming_$me')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: me),
          callback: (pl) => _incoming(pl.newRecord),
        )
        .subscribe();
  }

  @override
  void dispose() {
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Future<void> _incoming(Map<String, dynamic> c) async {
    final who = await sb.from('profiles').select('name').eq('id', c['caller_id']).single();
    if (!mounted) return;
    final ok = await showCupertinoDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (d) => CupertinoAlertDialog(
        title: Text('${t('incoming')} ${c['kind'] == 'video' ? t('video') : t('audio')}'),
        content: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(who['name'] ?? '', style: const TextStyle(fontSize: 20)),
        ),
        actions: [
          CupertinoDialogAction(isDestructiveAction: true, onPressed: () => Navigator.pop(d, false), child: Text(t('decline'))),
          CupertinoDialogAction(isDefaultAction: true, onPressed: () => Navigator.pop(d, true), child: Text(t('accept'))),
        ],
      ),
    );
    if (ok == true) {
      await sb.from('calls').update({'status': 'answered'}).eq('id', c['id']);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => CallPage(callId: c['id'], caller: false, video: c['kind'] == 'video', peer: who['name'] ?? '')));
    } else {
      await sb.from('calls').update({'status': 'declined'}).eq('id', c['id']);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [const ChatsPage(), const CallsPage(), const SettingsPage(), const ProfilePage()];
    final keyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;
    return Scaffold(
      body: Stack(children: [
        Positioned.fill(child: IndexedStack(index: i, children: pages)),
        if (!keyboardOpen)
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: GlassTabBar(
              index: i,
              onChanged: (v) {
                tabIndex.value = v;
                setState(() => i = v);
              },
              items: [
                TabItem(Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded, t('chats')),
                TabItem(Icons.call_outlined, Icons.call_rounded, t('calls')),
                TabItem(Icons.settings_outlined, Icons.settings_rounded, t('settings')),
                TabItem(Icons.person_outline_rounded, Icons.person_rounded, t('profile')),
              ],
            ),
          ),
      ]),
    );
  }
}
