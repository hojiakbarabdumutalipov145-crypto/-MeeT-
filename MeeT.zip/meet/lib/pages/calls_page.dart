import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';
import '../widgets.dart';

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  late Future<List<Map<String, dynamic>>> f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final r = await sb
        .from('calls')
        .select('*, caller:profiles!calls_caller_id_fkey(name), callee:profiles!calls_callee_id_fkey(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(r);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: () async => setState(() => f = _load()),
        child: ListView(padding: tabPad(context), children: [
          LargeTitle(t('calls')),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: f,
            builder: (context, s) {
              if (s.connectionState != ConnectionState.done) {
                return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()));
              }
              if (s.hasError) return Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('${s.error}')));
              final list = s.data!;
              if (list.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 64),
                  child: Column(children: [
                    const Icon(Icons.call_outlined, size: 48, color: kGray),
                    const SizedBox(height: 12),
                    Text(t('noCalls'), style: const TextStyle(color: kGray, fontSize: 16)),
                  ]),
                );
              }
              return Group(
                indent: 76,
                children: [
                  for (final c in list) _tile(context, c),
                ],
              );
            },
          ),
        ]),
      ),
    );
  }

  Widget _tile(BuildContext context, Map<String, dynamic> c) {
    final out = c['caller_id'] == me;
    final name = (out ? c['callee'] : c['caller'])?['name'] ?? '?';
    final peerId = out ? c['callee_id'] : c['caller_id'];
    final missed = !out && c['status'] != 'answered';
    final d = DateTime.parse(c['created_at']).toLocal();
    final when = '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')} '
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return Cell(
      leading: avatar(null, name),
      title: name,
      bold: true,
      titleColor: missed ? kRed : null,
      subtitle: Row(children: [
        Icon(out ? Icons.call_made_rounded : (missed ? Icons.call_missed_rounded : Icons.call_received_rounded),
            size: 15, color: missed ? kRed : kGreen),
        const SizedBox(width: 4),
        Flexible(
          child: Text(missed ? '${t('missed')} · $when' : when,
              maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, color: kGray)),
        ),
      ]),
      trailing: Pressable(
        onTap: () => startCall(context, peerId, name, c['kind']),
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(color: kBlue.withOpacity(0.12), shape: BoxShape.circle),
          child: Icon(c['kind'] == 'video' ? Icons.videocam_rounded : Icons.call_rounded, color: kBlue, size: 20),
        ),
      ),
    );
  }
}
