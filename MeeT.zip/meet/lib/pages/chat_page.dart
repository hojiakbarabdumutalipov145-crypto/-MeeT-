import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../core.dart';
import '../l10n.dart';
import '../widgets.dart';
import '../glass.dart';
import '../media.dart';
import '../circle_recorder.dart';

class ChatPage extends StatefulWidget {
  final Map<String, dynamic> chat;
  const ChatPage({super.key, required this.chat});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctl = TextEditingController();
  final picker = ImagePicker();
  final rec = AudioRecorder();
  late final Stream<List<Map<String, dynamic>>> stream = sb
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('chat_id', widget.chat['id'])
      .order('created_at', ascending: false)
      .limit(200);

  bool hasText = false, recording = false, uploading = false;
  int recSecs = 0;
  Timer? recTimer;

  bool get direct => widget.chat['type'] == 'direct';
  bool get readOnly => widget.chat['type'] == 'channel' && widget.chat['created_by'] != me;

  @override
  void dispose() {
    recTimer?.cancel();
    rec.dispose();
    ctl.dispose();
    super.dispose();
  }

  // ---------- Matn ----------

  Future<void> _send() async {
    final text = ctl.text.trim();
    if (text.isEmpty) return;
    ctl.clear();
    setState(() => hasText = false);
    try {
      await sb.from('messages').insert({'chat_id': widget.chat['id'], 'sender_id': me, 'type': 'text', 'content': text});
    } catch (e) {
      if (mounted) {
        ctl.text = text;
        ctl.selection = TextSelection.collapsed(offset: text.length);
        setState(() => hasText = true);
        snack(context, '$e');
      }
    }
  }

  // ---------- Media yuborish ----------

  Future<void> _sendMedia(String type, String ext, String ct, Uint8List bytes, {String content = ''}) async {
    if (bytes.length > kMaxUpload) {
      if (mounted) snack(context, t('tooBig'));
      return;
    }
    if (mounted) setState(() => uploading = true);
    try {
      final path = await uploadMedia(widget.chat['id'], bytes, ext, ct);
      await sb.from('messages').insert({
        'chat_id': widget.chat['id'],
        'sender_id': me,
        'type': type,
        'content': content,
        'media_url': path,
      });
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    if (mounted) setState(() => uploading = false);
  }

  Future<void> _pickImage(ImageSource src) async {
    try {
      final x = await picker.pickImage(source: src, imageQuality: 85, maxWidth: 1920);
      if (x == null) return;
      final ext = safeExt(x.name, 'jpg');
      final ct = 'image/${ext == 'jpg' ? 'jpeg' : ext}';
      await _sendMedia('image', ext, ct, await x.readAsBytes());
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _pickRoundVideo() async {
    try {
      XFile? x;
      if (isMobile) {
        x = await Navigator.push<XFile?>(context, MaterialPageRoute(fullscreenDialog: true, builder: (_) => const CircleRecorderPage()));
      } else {
        x = await picker.pickVideo(source: ImageSource.gallery);
      }
      if (x == null) return;
      final ext = safeExt(x.name, 'mp4');
      await _sendMedia('video_note', ext, ext == 'mov' ? 'video/quicktime' : 'video/mp4', await x.readAsBytes());
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _pickFile() async {
    try {
      final r = await FilePicker.platform.pickFiles(withData: true);
      if (r == null || r.files.isEmpty) return;
      final f = r.files.first;
      if (f.size > kMaxUpload) {
        if (mounted) snack(context, t('tooBig'));
        return;
      }
      final bytes = f.bytes ?? (f.path != null ? await File(f.path!).readAsBytes() : null);
      if (bytes == null) return;
      await _sendMedia('file', safeExt(f.name, 'bin'), 'application/octet-stream', bytes, content: f.name);
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  // ---------- Ovozli xabar ----------

  Future<void> _startRec() async {
    try {
      if (!await rec.hasPermission()) {
        if (mounted) snack(context, t('micDenied'));
        return;
      }
      final dir = await getTemporaryDirectory();
      final p = '${dir.path}/v_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await rec.start(const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 44100), path: p);
      recSecs = 0;
      recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => recSecs++);
        if (recSecs >= 600) _stopRec(send: true); // 10 daqiqa chegarasi
      });
      setState(() => recording = true);
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _stopRec({required bool send}) async {
    if (!recording) return;
    recording = false;
    recTimer?.cancel();
    final secs = recSecs;
    String? p;
    try {
      p = await rec.stop();
    } catch (_) {}
    if (mounted) setState(() {});
    if (p == null) return;
    try {
      if (send && secs >= 1) {
        await _sendMedia('voice', 'm4a', 'audio/mp4', await File(p).readAsBytes(), content: '$secs');
      }
    } finally {
      try { await File(p).delete(); } catch (_) {}
    }
  }

  // ---------- Aʼzo qoʻshish ----------

  Future<void> _addMember() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    try {
      await sb.from('chat_members').insert({'chat_id': widget.chat['id'], 'user_id': p['id']});
      if (mounted) snack(context, t('saved'));
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  void _attachSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (d) => SafeArea(
        child: Glass(
          radius: 30, margin: const EdgeInsets.fromLTRB(14, 0, 14, 14), padding: const EdgeInsets.symmetric(vertical: 8),
          child: Material(
            color: Colors.transparent,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(leading: const Icon(Icons.photo_library_outlined), title: Text(t('gallery')), onTap: () { Navigator.pop(d); _pickImage(ImageSource.gallery); }),
              if (isMobile)
                ListTile(leading: const Icon(Icons.photo_camera_outlined), title: Text(t('camera')), onTap: () { Navigator.pop(d); _pickImage(ImageSource.camera); }),
              ListTile(leading: const Icon(Icons.insert_drive_file_outlined), title: Text(t('file')), onTap: () { Navigator.pop(d); _pickFile(); }),
              ListTile(leading: const Icon(Icons.videocam_outlined), title: Text(t('roundVideo')), onTap: () { Navigator.pop(d); _pickRoundVideo(); }),
            ]),
          ),
        ),
      ),
    );
  }

  // ---------- Xabar koʻrinishi ----------

  Widget _content(Map<String, dynamic> m, bool mine) {
    final type = (m['type'] ?? 'text') as String;
    final path = m['media_url'] as String?;
    final c = (m['content'] ?? '') as String;
    final col = mine ? Colors.white : null;
    if (path != null) {
      switch (type) {
        case 'image':
          return Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            ChatImage(path: path),
            if (c.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(c, style: TextStyle(fontSize: 16, color: col))),
          ]);
        case 'voice':
          return VoiceBubble(path: path, secs: int.tryParse(c) ?? 0, mine: mine);
        case 'file':
          return FileTile(path: path, name: c, mine: mine);
      }
    }
    return Text(c, style: TextStyle(fontSize: 16, color: col));
  }

  Widget _msg(Map<String, dynamic> m) {
    final mine = m['sender_id'] == me;
    final time = DateTime.parse(m['created_at']).toLocal();
    final hh = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    final d = isDark(context);

    // Dumaloq video — pufaksiz, toʻgʻridan-toʻgʻri doira
    if (m['type'] == 'video_note' && m['media_url'] != null) {
      return Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Column(crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            VideoNote(path: m['media_url'], mine: mine),
            const SizedBox(height: 3),
            Text(hh, style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ]),
        ),
      );
    }

    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.fromLTRB(14, 9, 12, 7),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          gradient: mine
              ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xE62F7BFF), Color(0xCC22B8E8)])
              : LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(d ? 0.16 : 0.8), Colors.white.withOpacity(d ? 0.06 : 0.45)]),
          border: Border.all(color: Colors.white.withOpacity(mine ? 0.45 : (d ? 0.22 : 0.9))),
          boxShadow: [BoxShadow(color: (mine ? kBlue : Colors.black).withOpacity(0.12), blurRadius: 12, offset: const Offset(0, 4))],
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(mine ? 18 : 4), bottomRight: Radius.circular(mine ? 4 : 18),
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
          _content(m, mine),
          const SizedBox(height: 2),
          Text(hh, style: TextStyle(fontSize: 11, color: mine ? Colors.white70 : Colors.grey)),
        ]),
      ),
    );
  }

  Widget _sendBtn(IconData icon, VoidCallback f) => Container(
        decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [kBlue, kCyan])),
        child: IconButton(icon: Icon(icon, color: Colors.white), onPressed: f),
      );

  Widget _inputBar() {
    if (recording) {
      return Glass(
        radius: 30, blur: 20, padding: const EdgeInsets.fromLTRB(6, 5, 5, 5),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: () => _stopRec(send: false)),
          const Icon(Icons.fiber_manual_record, color: Colors.red, size: 14),
          const SizedBox(width: 8),
          Expanded(child: Text(fmtSecs(recSecs), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
          _sendBtn(Icons.send_rounded, () => _stopRec(send: true)),
        ]),
      );
    }
    return Glass(
      radius: 30, blur: 20, padding: const EdgeInsets.fromLTRB(6, 5, 5, 5),
      child: Row(children: [
        IconButton(icon: const Icon(Icons.attach_file), onPressed: uploading ? null : _attachSheet),
        Expanded(
          child: TextField(
            controller: ctl,
            minLines: 1, maxLines: 5,
            onChanged: (v) {
              final h = v.trim().isNotEmpty;
              if (h != hasText) setState(() => hasText = h);
            },
            onSubmitted: (_) => _send(),
            decoration: InputDecoration(
              hintText: t('message'), filled: false,
              border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
            ),
          ),
        ),
        if (hasText)
          _sendBtn(Icons.send_rounded, _send)
        else ...[
          IconButton(icon: const Icon(Icons.videocam_outlined), onPressed: uploading ? null : _pickRoundVideo),
          _sendBtn(Icons.mic, uploading ? () {} : _startRec),
        ],
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.chat['title'] ?? '';
    final peer = widget.chat['peer'] as String?;
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: glassBar(),
        title: Text(title),
        actions: [
          if (direct && peer != null) ...[
            IconButton(icon: const Icon(Icons.call), onPressed: () => startCall(context, peer, title, 'audio')),
            IconButton(icon: const Icon(Icons.videocam), onPressed: () => startCall(context, peer, title, 'video')),
          ] else if (!direct && widget.chat['created_by'] == me)
            IconButton(icon: const Icon(Icons.person_add), tooltip: t('addMember'), onPressed: _addMember),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: stream,
            builder: (context, s) {
              if (s.hasError) return Center(child: Text('${s.error}'));
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final msgs = s.data!;
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: msgs.length,
                itemBuilder: (_, k) => _msg(msgs[k]),
              );
            },
          ),
        ),
        if (uploading) const LinearProgressIndicator(minHeight: 2),
        SafeArea(
          top: false,
          child: readOnly
              ? Padding(padding: const EdgeInsets.all(16), child: Text(t('channelReadonly'), style: const TextStyle(color: Colors.grey)))
              : Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 8), child: _inputBar()),
        ),
      ]),
    );
  }
}
