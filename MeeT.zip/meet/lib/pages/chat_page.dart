import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';
import '../widgets.dart';

class ChatPage extends StatefulWidget {
  final Map<String, dynamic> chat;
  const ChatPage({super.key, required this.chat});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctl = TextEditingController();
  late final Stream<List<Map<String, dynamic>>> stream = sb
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('chat_id', widget.chat['id'])
      .order('created_at', ascending: false);

  bool get direct => widget.chat['type'] == 'direct';
  bool get readOnly => widget.chat['type'] == 'channel' && widget.chat['created_by'] != me;

  Future<void> _send() async {
    final text = ctl.text.trim();
    if (text.isEmpty) return;
    ctl.clear();
    try {
      await sb.from('messages').insert({'chat_id': widget.chat['id'], 'sender_id': me, 'type': 'text', 'content': text});
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _addMember() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    try {
      await sb.from('chat_members').insert({'chat_id': widget.chat['id'], 'user_id': p['id']});
      if (mounted) snack(context, t('saved'));
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.chat['title'] ?? '';
    final peer = widget.chat['peer'] as String?;
    final dark = isDark(context);
    final otherBubble = dark ? const Color(0xFF26262A) : const Color(0xFFE9E9EB);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: kBlue),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          if (direct) avatar(widget.chat['avatar'], title, r: 16)
          else CircleAvatar(
            radius: 16,
            backgroundColor: kBlue.withOpacity(0.15),
            child: Icon(widget.chat['type'] == 'channel' ? Icons.campaign_rounded : Icons.group_rounded, size: 18, color: kBlue),
          ),
          const SizedBox(width: 10),
          Flexible(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis)),
        ]),
        actions: [
          if (direct && peer != null) ...[
            IconButton(icon: const Icon(Icons.call_rounded, color: kBlue), onPressed: () => startCall(context, peer, title, 'audio')),
            IconButton(icon: const Icon(Icons.videocam_rounded, color: kBlue), onPressed: () => startCall(context, peer, title, 'video')),
          ] else if (!direct && widget.chat['created_by'] == me)
            IconButton(icon: const Icon(Icons.person_add_alt_1_rounded, color: kBlue), tooltip: t('addMember'), onPressed: _addMember),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: stream,
            builder: (context, s) {
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final msgs = s.data!;
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: msgs.length,
                itemBuilder: (_, k) {
                  final m = msgs[k];
                  final mine = m['sender_id'] == me;
                  final time = DateTime.parse(m['created_at']).toLocal();
                  final hh = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
                  return Align(
                    alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 2),
                      padding: const EdgeInsets.fromLTRB(14, 8, 12, 6),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                      decoration: BoxDecoration(
                        color: mine ? kBlue : otherBubble,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(20), topRight: const Radius.circular(20),
                          bottomLeft: Radius.circular(mine ? 20 : 6), bottomRight: Radius.circular(mine ? 6 : 20),
                        ),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                        Text(m['content'] ?? '', style: TextStyle(fontSize: 17, color: mine ? Colors.white : (dark ? Colors.white : Colors.black))),
                        const SizedBox(height: 2),
                        Text(hh, style: TextStyle(fontSize: 11, color: mine ? Colors.white70 : kGray)),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          top: false,
          child: readOnly
              ? Padding(padding: const EdgeInsets.all(16), child: Text(t('channelReadonly'), style: const TextStyle(color: kGray)))
              : Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Expanded(
                      child: TextField(
                        controller: ctl,
                        minLines: 1,
                        maxLines: 5,
                        textCapitalization: TextCapitalization.sentences,
                        style: const TextStyle(fontSize: 17),
                        decoration: InputDecoration(
                          hintText: t('message'),
                          hintStyle: const TextStyle(color: kGray),
                          filled: true,
                          fillColor: cardOf(context),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: lineOf(context), width: 0.8)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: lineOf(context), width: 0.8)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: lineOf(context), width: 0.8)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ValueListenableBuilder<TextEditingValue>(
                      valueListenable: ctl,
                      builder: (_, v, __) {
                        final has = v.text.trim().isNotEmpty;
                        return Pressable(
                          onTap: has ? _send : null,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(color: has ? kBlue : kGray.withOpacity(0.4), shape: BoxShape.circle),
                            child: const Icon(Icons.arrow_upward_rounded, color: Colors.white, size: 22),
                          ),
                        );
                      },
                    ),
                  ]),
                ),
        ),
      ]),
    );
  }
}
