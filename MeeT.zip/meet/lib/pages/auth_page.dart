import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool signup = false, loading = false, hide = true;
  String? error;
  final u = TextEditingController(), p = TextEditingController(), n = TextEditingController();

  Future<void> submit() async {
    final user = u.text.trim().toLowerCase();
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(user)) return setState(() => error = t('badUsername'));
    if (p.text.length < 6) return setState(() => error = t('badPassword'));
    setState(() { loading = true; error = null; });
    try {
      final email = '$user@meet.app';
      if (signup) {
        await sb.auth.signUp(email: email, password: p.text, data: {
          'username': user,
          'name': n.text.trim().isEmpty ? user : n.text.trim(),
        });
      } else {
        await sb.auth.signInWithPassword(email: email, password: p.text);
      }
    } on AuthException catch (e) {
      error = e.message;
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 30, offset: const Offset(0, 12))],
                  ),
                  child: ClipRRect(borderRadius: BorderRadius.circular(26), child: Image.asset('assets/logo.png', width: 104)),
                ),
                const SizedBox(height: 24),
                Text(signup ? t('signup') : t('signin'),
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
                const SizedBox(height: 24),
                Group(children: [
                  if (signup) FieldCell(controller: n, hint: t('name'), icon: Icons.badge_outlined),
                  FieldCell(controller: u, hint: t('username'), icon: Icons.alternate_email_rounded),
                  FieldCell(
                    controller: p,
                    hint: t('password'),
                    icon: Icons.lock_outline_rounded,
                    obscure: hide,
                    onSubmitted: (_) => submit(),
                    suffix: GestureDetector(
                      onTap: () => setState(() => hide = !hide),
                      child: Icon(hide ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: kGray),
                    ),
                  ),
                ]),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: kRed, fontSize: 14)),
                  ),
                const SizedBox(height: 24),
                PillButton(signup ? t('signup') : t('signin'), onPressed: submit, loading: loading),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => setState(() { signup = !signup; error = null; }),
                  child: Text(signup ? t('haveAcc') : t('noAcc'), style: const TextStyle(fontSize: 16, color: kBlue)),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
