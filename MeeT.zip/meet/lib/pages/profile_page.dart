import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';
import '../widgets.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Map<String, dynamic>? p;
  int chatCount = 0, callCount = 0, days = 1;
  final name = TextEditingController(), bio = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await sb.from('profiles').select().eq('id', me).single();
    name.text = r['name'] ?? '';
    bio.text = r['bio'] ?? '';
    try {
      days = DateTime.now().difference(DateTime.parse(r['created_at'].toString())).inDays + 1;
    } catch (_) {}
    if (mounted) setState(() => p = r);
    try {
      final chats = await sb.from('chat_members').select('chat_id').eq('user_id', me);
      final calls = await sb.from('calls').select('id').or('caller_id.eq.$me,callee_id.eq.$me');
      if (mounted) setState(() { chatCount = (chats as List).length; callCount = (calls as List).length; });
    } catch (_) {}
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 85);
    if (x == null) return;
    try {
      final bytes = await x.readAsBytes();
      await sb.storage.from('avatars').uploadBinary('$me.jpg', bytes,
          fileOptions: const FileOptions(upsert: true, contentType: 'image/jpeg'));
      final url = '${sb.storage.from('avatars').getPublicUrl('$me.jpg')}?t=${DateTime.now().millisecondsSinceEpoch}';
      await sb.from('profiles').update({'avatar_url': url}).eq('id', me);
      _load();
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _save() async {
    await sb.from('profiles').update({'name': name.text.trim(), 'bio': bio.text.trim()}).eq('id', me);
    if (mounted) snack(context, t('saved'));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: p == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: tabPad(context), children: [
              LargeTitle(t('profile')),
              const SizedBox(height: 8),
              Center(
                child: Pressable(
                  onTap: _pick,
                  child: Stack(children: [
                    avatar(p!['avatar_url'], p!['name'] ?? '', r: 56),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: kBlue,
                          shape: BoxShape.circle,
                          border: Border.all(color: bgOf(context), width: 3),
                        ),
                        child: const Icon(Icons.camera_alt_rounded, size: 16, color: Colors.white),
                      ),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 14),
              Center(child: Text(p!['name'] ?? '', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700))),
              const SizedBox(height: 2),
              Center(child: Text('@${p!['username']}', style: const TextStyle(fontSize: 16, color: kGray))),
              const SizedBox(height: 20),
              StatsBlock([
                ['$chatCount', t('chats')],
                ['$callCount', t('calls')],
                ['$days', t('days')],
              ]),
              SectionLabel(t('info')),
              Group(indent: 16, children: [
                FieldCell(controller: name, hint: t('name'), icon: Icons.badge_outlined),
                FieldCell(controller: bio, hint: t('bio'), icon: Icons.info_outline_rounded, maxLines: 3),
              ]),
              const SizedBox(height: 24),
              PillButton(t('save'), onPressed: _save),
            ]),
    );
  }
}
