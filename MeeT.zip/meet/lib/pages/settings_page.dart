import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';
import '../widgets.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late Future<Map<String, dynamic>> prof = sb.from('profiles').select().eq('id', me).single();

  Future<void> _setTheme(ThemeMode m) async {
    themeMode.value = m;
    (await SharedPreferences.getInstance()).setInt('theme', m.index);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ListView(padding: tabPad(context), children: [
        LargeTitle(t('settings')),
        FutureBuilder<Map<String, dynamic>>(
          future: prof,
          builder: (_, s) {
            final p = s.data;
            return Group(indent: 84, children: [
              InkWell(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountPage())),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    avatar(p?['avatar_url'], p?['name'] ?? '', r: 32),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(p?['name'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 2),
                        Text(p == null ? '' : '@${p['username']}', style: const TextStyle(fontSize: 15, color: kGray)),
                      ]),
                    ),
                    const Chevron(),
                  ]),
                ),
              ),
            ]);
          },
        ),
        SectionLabel(t('general')),
        Group(indent: 57, children: [
          Cell(
            leading: const IconBadge(Icons.person_rounded, kBlue),
            title: t('account'),
            trailing: const Chevron(),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountPage())),
          ),
          Cell(
            leading: const IconBadge(Icons.lock_rounded, kGreen),
            title: t('privacy'),
            trailing: const Chevron(),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPage())),
          ),
        ]),
        SectionLabel(t('appearance')),
        ValueListenableBuilder<ThemeMode>(
          valueListenable: themeMode,
          builder: (ctx, m, __) {
            final auto = m == ThemeMode.system;
            return Group(indent: 57, children: [
              Cell(
                leading: const IconBadge(Icons.brightness_auto_rounded, kGray),
                title: t('auto'),
                trailing: CupertinoSwitch(
                  value: auto,
                  onChanged: (v) => _setTheme(v ? ThemeMode.system : (isDark(ctx) ? ThemeMode.dark : ThemeMode.light)),
                ),
              ),
              Cell(
                leading: const IconBadge(Icons.dark_mode_rounded, kIndigo),
                title: t('darkMode'),
                trailing: CupertinoSwitch(
                  value: isDark(ctx),
                  onChanged: auto ? null : (v) => _setTheme(v ? ThemeMode.dark : ThemeMode.light),
                ),
              ),
              Cell(
                leading: const IconBadge(Icons.language_rounded, kOrange),
                title: t('language'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(langNames[appLocale.value] ?? '', style: const TextStyle(fontSize: 17, color: kGray)),
                  const Chevron(),
                ]),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LanguagePage())),
              ),
            ]);
          },
        ),
        const SizedBox(height: 24),
        Group(children: [
          Cell(
            title: t('logout'),
            titleColor: kRed,
            onTap: () => sb.auth.signOut(),
          ),
        ]),
      ]),
    );
  }
}

class LanguagePage extends StatelessWidget {
  const LanguagePage({super.key});

  Future<void> _setLang(String l) async {
    (await SharedPreferences.getInstance()).setString('lang', l);
    appLocale.value = l;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('language'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Group(children: [
          for (final e in langNames.entries)
            Cell(
              title: e.value,
              trailing: appLocale.value == e.key ? const Icon(Icons.check_rounded, color: kBlue) : null,
              onTap: () => _setLang(e.key),
            ),
        ]),
      ]),
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 17)),
          const SizedBox(width: 16),
          Expanded(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontSize: 17, color: kGray))),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('account'))),
      body: FutureBuilder<Map<String, dynamic>>(
        future: sb.from('profiles').select().eq('id', me).single(),
        builder: (_, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final p = s.data!;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Center(child: avatar(p['avatar_url'], p['name'] ?? '', r: 48))),
            Group(children: [
              _row(t('name'), p['name'] ?? ''),
              _row(t('username'), '@${p['username']}'),
              _row(t('bio'), p['bio'] ?? ''),
              _row(t('joined'), p['created_at'].toString().substring(0, 10)),
              _row(t('userId'), p['id']),
            ]),
          ]);
        },
      ),
    );
  }
}

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  Future<void> _changeUsername(BuildContext c) async {
    final v = (await ask(c, t('newUsername')))?.toLowerCase();
    if (v == null || v.isEmpty) return;
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(v)) { snack(c, t('badUsername')); return; }
    try {
      await sb.from('profiles').update({'username': v}).eq('id', me);
      await sb.auth.updateUser(UserAttributes(email: '$v@meet.app'));
      if (c.mounted) snack(c, t('saved'));
    } catch (e) {
      if (c.mounted) snack(c, '$e');
    }
  }

  Future<void> _changePassword(BuildContext c) async {
    final v = await ask(c, t('newPassword'), obscure: true);
    if (v == null || v.isEmpty) return;
    if (v.length < 6) { snack(c, t('badPassword')); return; }
    try {
      await sb.auth.updateUser(UserAttributes(password: v));
      if (c.mounted) snack(c, t('saved'));
    } catch (e) {
      if (c.mounted) snack(c, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('privacy'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Group(indent: 57, children: [
          Cell(
            leading: const IconBadge(Icons.alternate_email_rounded, kBlue),
            title: t('newUsername'),
            trailing: const Chevron(),
            onTap: () => _changeUsername(context),
          ),
          Cell(
            leading: const IconBadge(Icons.key_rounded, kOrange),
            title: t('newPassword'),
            trailing: const Chevron(),
            onTap: () => _changePassword(context),
          ),
        ]),
      ]),
    );
  }
}
