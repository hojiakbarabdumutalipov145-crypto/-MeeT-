import 'package:flutter/material.dart';
import '../core.dart';
import '../l10n.dart';
import '../ui.dart';
import '../widgets.dart';
import 'chat_page.dart';

class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  late Future<List<Map<String, dynamic>>> f = _load();
  Map<String, dynamic>? prof;
  String q = '';

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final r = await sb.from('profiles').select('name,avatar_url').eq('id', me).single();
      if (mounted) setState(() => prof = r);
    } catch (_) {}
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await sb.from('chat_members').select('chats(id,type,title,created_by)').eq('user_id', me);
    final out = <Map<String, dynamic>>[];
    for (final r in rows) {
      final c = Map<String, dynamic>.from(r['chats'] as Map);
      if (c['type'] == 'direct') {
        final o = await sb.from('chat_members').select('user_id,profiles(name,username,avatar_url)')
            .eq('chat_id', c['id']).neq('user_id', me).maybeSingle();
        final pr = o?['profiles'] as Map?;
        c['title'] = pr?['name'] ?? pr?['username'] ?? '?';
        c['avatar'] = pr?['avatar_url'];
        c['peer'] = o?['user_id'];
      }
      out.add(c);
    }
    return out;
  }

  void _reload() => setState(() => f = _load());

  Future<void> _newDirect() async {
    final u = await ask(context, t('username'));
    if (u == null || u.isEmpty) return;
    final p = await sb.from('profiles').select('id').eq('username', u.toLowerCase().replaceAll('@', '')).maybeSingle();
    if (p == null) { if (mounted) snack(context, t('notFound')); return; }
    if (p['id'] == me) return;
    final c = await sb.from('chats').insert({'type': 'direct', 'created_by': me}).select().single();
    await sb.from('chat_members').insert([
      {'chat_id': c['id'], 'user_id': me},
      {'chat_id': c['id'], 'user_id': p['id']},
    ]);
    _reload();
  }

  Future<void> _newGroup(String type) async {
    final title = await ask(context, t('title'));
    if (title == null || title.isEmpty) return;
    final c = await sb.from('chats').insert({'type': type, 'title': title, 'created_by': me}).select().single();
    await sb.from('chat_members').insert({'chat_id': c['id'], 'user_id': me});
    _reload();
  }

  void _sheet() {
    showModalBottomSheet(
      context: context,
      builder: (d) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Group(
            indent: 57,
            children: [
              Cell(leading: const IconBadge(Icons.person_add_alt_1_rounded, kBlue), title: t('newDirect'), trailing: const Chevron(),
                  onTap: () { Navigator.pop(d); _newDirect(); }),
              Cell(leading: const IconBadge(Icons.group_add_rounded, kGreen), title: t('newGroup'), trailing: const Chevron(),
                  onTap: () { Navigator.pop(d); _newGroup('group'); }),
              Cell(leading: const IconBadge(Icons.campaign_rounded, kOrange), title: t('newChannel'), trailing: const Chevron(),
                  onTap: () { Navigator.pop(d); _newGroup('channel'); }),
            ],
          ),
        ),
      ),
    );
  }

  String _typeLabel(String? type) => type == 'channel' ? t('channel') : type == 'group' ? t('group') : t('private');

  @override
  Widget build(BuildContext context) {
    final name = (prof?['name'] ?? '') as String;
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: () async { _loadProfile(); _reload(); },
        child: ListView(padding: tabPad(context), children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 8, 4, 4),
            child: Row(children: [
              avatar(prof?['avatar_url'], name, r: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t('welcome'), style: const TextStyle(fontSize: 13, color: kGray)),
                  Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                ]),
              ),
              Pressable(
                onTap: _sheet,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(color: kBlue, shape: BoxShape.circle),
                  child: const Icon(Icons.edit_rounded, color: Colors.white, size: 20),
                ),
              ),
            ]),
          ),
          LargeTitle(t('chats')),
          SearchField(hint: t('search'), onChanged: (v) => setState(() => q = v.trim().toLowerCase())),
          const SizedBox(height: 16),
          Pressable(
            onTap: _sheet,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0A5CFF), Color(0xFF38B6FF)]),
              ),
              child: Row(children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.campaign_rounded, color: Colors.white),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(t('bannerTitle'), style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 2),
                    Text(t('bannerSub'), style: const TextStyle(color: Colors.white70, fontSize: 14)),
                  ]),
                ),
                const Icon(Icons.chevron_right_rounded, color: Colors.white70),
              ]),
            ),
          ),
          const SizedBox(height: 20),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: f,
            builder: (context, s) {
              if (s.connectionState != ConnectionState.done) {
                return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()));
              }
              if (s.hasError) return Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('${s.error}')));
              final list = s.data!.where((c) => q.isEmpty || (c['title'] ?? '').toString().toLowerCase().contains(q)).toList();
              if (list.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 48),
                  child: Column(children: [
                    const Icon(Icons.chat_bubble_outline_rounded, size: 48, color: kGray),
                    const SizedBox(height: 12),
                    Text(t('noChats'), style: const TextStyle(color: kGray, fontSize: 16)),
                  ]),
                );
              }
              return Group(
                indent: 76,
                children: [
                  for (final c in list)
                    Cell(
                      leading: c['type'] == 'direct'
                          ? avatar(c['avatar'], c['title'] ?? '')
                          : CircleAvatar(
                              radius: 24,
                              backgroundColor: kBlue.withOpacity(0.15),
                              child: Icon(c['type'] == 'channel' ? Icons.campaign_rounded : Icons.group_rounded, color: kBlue),
                            ),
                      title: c['title'] ?? '',
                      bold: true,
                      subtitle: Text(_typeLabel(c['type']), style: const TextStyle(fontSize: 14, color: kGray)),
                      trailing: const Chevron(),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chat: c)));
                        _reload();
                      },
                    ),
                ],
              );
            },
          ),
        ]),
      ),
    );
  }
}
