import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'core.dart';
import 'l10n.dart';
import 'widgets.dart';

/// Telegramdagidek: dumaloq oynada video yozib olish. Tugagach XFile qaytaradi.
class CircleRecorderPage extends StatefulWidget {
  const CircleRecorderPage({super.key});
  @override
  State<CircleRecorderPage> createState() => _CircleRecorderPageState();
}

class _CircleRecorderPageState extends State<CircleRecorderPage> with WidgetsBindingObserver {
  static const maxSecs = 60;
  List<CameraDescription> cams = [];
  CameraController? cc;
  int camIndex = 0;
  bool recording = false, busy = true;
  int secs = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init(front: true);
  }

  Future<void> _init({bool front = false}) async {
    try {
      if (cams.isEmpty) {
        cams = await availableCameras();
        if (cams.isEmpty) throw CameraException('none', 'No camera');
        final i = cams.indexWhere((c) => c.lensDirection == CameraLensDirection.front);
        camIndex = (front && i >= 0) ? i : 0;
      }
      final old = cc;
      final n = CameraController(cams[camIndex], ResolutionPreset.medium, enableAudio: true);
      await n.initialize();
      await old?.dispose();
      if (!mounted) {
        await n.dispose();
        return;
      }
      setState(() { cc = n; busy = false; });
    } catch (e) {
      if (mounted) {
        snack(context, t('camDenied'));
        Navigator.pop(context);
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.inactive && recording) _cancel();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    timer?.cancel();
    cc?.dispose();
    super.dispose();
  }

  Future<void> _flip() async {
    if (recording || cams.length < 2 || busy) return;
    setState(() => busy = true);
    camIndex = (camIndex + 1) % cams.length;
    await _init();
  }

  Future<void> _start() async {
    final c = cc;
    if (c == null || recording || busy) return;
    try {
      await c.prepareForVideoRecording();
      await c.startVideoRecording();
      secs = 0;
      timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => secs++);
        if (secs >= maxSecs) _finish();
      });
      setState(() => recording = true);
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _finish() async {
    final c = cc;
    if (c == null || !recording) return;
    timer?.cancel();
    recording = false;
    try {
      final f = await c.stopVideoRecording();
      if (mounted) Navigator.pop(context, secs >= 1 ? f : null);
    } catch (e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    }
  }

  Future<void> _cancel() async {
    final c = cc;
    timer?.cancel();
    if (c != null && recording) {
      recording = false;
      try { await c.stopVideoRecording(); } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = cc;
    final ready = c != null && c.value.isInitialized && !busy;
    final size = MediaQuery.of(context).size.width * 0.78;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: _cancel),
          ),
          const Spacer(),
          SizedBox(
            width: size + 16, height: size + 16,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: size + 12, height: size + 12,
                child: CircularProgressIndicator(
                  value: recording ? secs / maxSecs : 0,
                  strokeWidth: 4, color: Colors.redAccent, backgroundColor: Colors.white24,
                ),
              ),
              ClipOval(
                child: SizedBox(
                  width: size, height: size,
                  child: ready
                      ? FittedBox(
                          fit: BoxFit.cover,
                          clipBehavior: Clip.hardEdge,
                          child: SizedBox(
                            width: c.value.previewSize!.height,
                            height: c.value.previewSize!.width,
                            child: CameraPreview(c),
                          ),
                        )
                      : const Center(child: CircularProgressIndicator(color: Colors.white)),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 18),
          Text(
            recording ? fmtTime(secs) : t('tapToRecord'),
            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.only(bottom: 28),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              SizedBox(
                width: 56,
                child: recording
                    ? IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white, size: 30), onPressed: _cancel)
                    : null,
              ),
              GestureDetector(
                onTap: recording ? _finish : _start,
                child: Container(
                  width: 78, height: 78, padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 4)),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      color: Colors.redAccent,
                      shape: recording ? BoxShape.rectangle : BoxShape.circle,
                      borderRadius: recording ? BorderRadius.circular(10) : null,
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: 56,
                child: recording || cams.length < 2
                    ? null
                    : IconButton(
                        tooltip: t('flip'),
                        icon: const Icon(Icons.flip_camera_android_outlined, color: Colors.white, size: 30),
                        onPressed: _flip),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

String fmtTime(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';
