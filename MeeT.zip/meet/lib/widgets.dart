import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'core.dart';
import 'l10n.dart';
import 'pages/call_page.dart';

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

Future<String?> ask(BuildContext c, String title, {bool obscure = false}) {
  final ctl = TextEditingController();
  return showCupertinoDialog<String>(
    context: c,
    builder: (d) => CupertinoAlertDialog(
      title: Text(title),
      content: Padding(
        padding: const EdgeInsets.only(top: 12),
        child: CupertinoTextField(controller: ctl, autofocus: true, obscureText: obscure),
      ),
      actions: [
        CupertinoDialogAction(onPressed: () => Navigator.pop(d), child: Text(t('cancel'))),
        CupertinoDialogAction(isDefaultAction: true, onPressed: () => Navigator.pop(d, ctl.text.trim()), child: Text(t('save'))),
      ],
    ),
  );
}

Future<void> startCall(BuildContext c, String peerId, String peerName, String kind) async {
  try {
    final r = await sb.from('calls').insert({'caller_id': me, 'callee_id': peerId, 'kind': kind}).select().single();
    if (!c.mounted) return;
    Navigator.push(c, MaterialPageRoute(
        builder: (_) => CallPage(callId: r['id'], caller: true, video: kind == 'video', peer: peerName)));
  } catch (e) {
    if (c.mounted) snack(c, '$e');
  }
}
