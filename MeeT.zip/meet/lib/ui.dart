import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';

EdgeInsets tabPad(BuildContext c) => EdgeInsets.fromLTRB(16, 0, 16, 112 + MediaQuery.of(c).padding.bottom);

class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  const Pressable({super.key, required this.child, this.onTap, this.scale = 0.97});
  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool down = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => down = true),
        onTapUp: (_) => setState(() => down = false),
        onTapCancel: () => setState(() => down = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: down ? widget.scale : 1,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      );
}

class LargeTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const LargeTitle(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 12),
        child: Row(children: [
          Expanded(child: Text(text, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700, letterSpacing: 0.3))),
          if (trailing != null) trailing!,
        ]),
      );
}

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
        child: Text(text.toUpperCase(), style: const TextStyle(fontSize: 13, color: kGray)),
      );
}

class Group extends StatelessWidget {
  final List<Widget> children;
  final double indent;
  const Group({super.key, required this.children, this.indent = 16});
  @override
  Widget build(BuildContext context) => Material(
        color: cardOf(context),
        borderRadius: BorderRadius.circular(18),
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) Divider(height: 0.5, thickness: 0.5, indent: indent, color: lineOf(context)),
            children[i],
          ],
        ]),
      );
}

class Cell extends StatelessWidget {
  final Widget? leading;
  final String title;
  final Color? titleColor;
  final Widget? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool bold;
  const Cell({super.key, this.leading, required this.title, this.titleColor, this.subtitle, this.trailing, this.onTap, this.bold = false});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 48),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              if (leading != null) ...[leading!, const SizedBox(width: 12)],
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 17, color: titleColor, fontWeight: bold ? FontWeight.w600 : FontWeight.w400)),
                  if (subtitle != null) ...[const SizedBox(height: 2), subtitle!],
                ]),
              ),
              if (trailing != null) ...[const SizedBox(width: 8), trailing!],
            ]),
          ),
        ),
      );
}

class IconBadge extends StatelessWidget {
  final IconData icon;
  final Color color;
  const IconBadge(this.icon, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 29,
        height: 29,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(7)),
        child: Icon(icon, size: 18, color: Colors.white),
      );
}

class Chevron extends StatelessWidget {
  const Chevron({super.key});
  @override
  Widget build(BuildContext context) => const Icon(Icons.chevron_right_rounded, color: Color(0xFFC7C7CC), size: 24);
}

class SearchField extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  const SearchField({super.key, required this.hint, required this.onChanged});
  @override
  Widget build(BuildContext context) => TextField(
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: kGray),
          prefixIcon: const Icon(Icons.search_rounded, color: kGray, size: 22),
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 11),
        ),
      );
}

class PillButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final Color? color;
  const PillButton(this.label, {super.key, this.onPressed, this.loading = false, this.color});
  @override
  Widget build(BuildContext context) => Pressable(
        onTap: loading ? null : onPressed,
        child: Container(
          height: 52,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: color ?? kBlue, borderRadius: BorderRadius.circular(26)),
          child: loading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : Text(label, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
        ),
      );
}

class StatsBlock extends StatelessWidget {
  final List<List<String>> items; // [value, label]
  const StatsBlock(this.items, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(color: cardOf(context), borderRadius: BorderRadius.circular(18)),
        child: IntrinsicHeight(
          child: Row(children: [
            for (var i = 0; i < items.length; i++) ...[
              if (i > 0) VerticalDivider(width: 1, thickness: 0.5, color: lineOf(context)),
              Expanded(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(items[i][0], style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(items[i][1], style: const TextStyle(fontSize: 13, color: kGray)),
                ]),
              ),
            ],
          ]),
        ),
      );
}

class FieldCell extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData? icon;
  final bool obscure;
  final Widget? suffix;
  final int maxLines;
  final ValueChanged<String>? onSubmitted;
  const FieldCell({super.key, required this.controller, required this.hint, this.icon, this.obscure = false, this.suffix, this.maxLines = 1, this.onSubmitted});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          if (icon != null) ...[Icon(icon, size: 20, color: kGray), const SizedBox(width: 12)],
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              maxLines: obscure ? 1 : maxLines,
              onSubmitted: onSubmitted,
              style: const TextStyle(fontSize: 17),
              decoration: InputDecoration(
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                filled: false,
                hintText: hint,
                hintStyle: const TextStyle(color: Color(0xFFC7C7CC)),
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
              ),
            ),
          ),
          if (suffix != null) suffix!,
        ]),
      );
}

class TabItem {
  final IconData icon, activeIcon;
  final String label;
  const TabItem(this.icon, this.activeIcon, this.label);
}

class GlassTabBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  final List<TabItem> items;
  const GlassTabBar({super.key, required this.index, required this.onChanged, required this.items});
  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final radius = BorderRadius.circular(34);
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: radius,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(dark ? 0.4 : 0.1), blurRadius: 24, offset: const Offset(0, 8))],
          ),
          child: ClipRRect(
            borderRadius: radius,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                height: 68,
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: dark ? const Color(0xB31C1C1E) : const Color(0xB3FFFFFF),
                  borderRadius: radius,
                  border: Border.all(color: dark ? const Color(0x33FFFFFF) : const Color(0xB3FFFFFF), width: 0.8),
                ),
                child: Row(children: [
                  for (var i = 0; i < items.length; i++)
                    Expanded(
                      child: Pressable(
                        onTap: () {
                          HapticFeedback.selectionClick();
                          onChanged(i);
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut,
                          decoration: BoxDecoration(
                            color: i == index ? (dark ? const Color(0x1FFFFFFF) : const Color(0x14000000)) : Colors.transparent,
                            borderRadius: BorderRadius.circular(28),
                          ),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(i == index ? items[i].activeIcon : items[i].icon, size: 24, color: i == index ? kBlue : kGray),
                            const SizedBox(height: 2),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(items[i].label,
                                  style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: i == index ? kBlue : kGray)),
                            ),
                          ]),
                        ),
                      ),
                    ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
